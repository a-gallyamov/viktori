/*
  Logi&ViktoRi Загрузчик прошивки

  1. Прошейте скетч через Arduino IDE
  2. Подключитесь к WiFi "Updater_192.168.4.1"
  3. Откройте http://192.168.4.1
  4. Выберите .bin файл и нажмите "Прошить"
*/

#ifdef ESP32
#include <Update.h>
#include <WebServer.h>
#include <WiFi.h>
WebServer server(80);
#else
#include <ESP8266WebServer.h>
#include <ESP8266WiFi.h>
#include <Updater.h>
ESP8266WebServer server(80);
#endif

bool updateOk = false;
String updateErr = "";

const char PAGE[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Logi&ViktoRi</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:Inter,system-ui,-apple-system,sans-serif;background:#1C1C1E;color:#e2e8f0;display:flex;justify-content:center;align-items:center;min-height:100vh}
.c{background:#1e293b;border:1px solid #334155;border-radius:16px;padding:36px;max-width:420px;width:90%;text-align:center;box-shadow:0 25px 50px -12px rgba(0,0,0,.5)}
h1{font-size:1.4em;margin-bottom:6px;color:#f8fafc;font-weight:700;letter-spacing:-.02em}
.sub{font-size:.85em;color:#94a3b8;margin-bottom:28px;font-weight:400}
.drop{border:2px dashed #475569;border-radius:12px;padding:36px 16px;margin-bottom:20px;cursor:pointer;transition:all .2s;color:#94a3b8}
.drop:hover,.drop.over{border-color:#6366f1;background:rgba(99,102,241,.06);color:#c7d2fe}
.drop small{color:#64748b}
.drop input{display:none}
.name{font-size:.85em;color:#a78bfa;margin-top:10px;word-break:break-all;font-weight:500}
button{background:#6366f1;color:#fff;border:none;border-radius:10px;padding:12px 32px;font-size:.95em;font-weight:600;cursor:pointer;width:100%;transition:all .2s;letter-spacing:.01em}
button:hover{background:#4f46e5;box-shadow:0 0 0 3px rgba(99,102,241,.3)}
button:disabled{background:#334155;color:#64748b;cursor:not-allowed;box-shadow:none}
.bar{background:#1C1C1E;border-radius:8px;height:8px;margin:20px 0;overflow:hidden;display:none}
.bar div{background:linear-gradient(90deg,#6366f1,#a78bfa);height:100%;width:0;border-radius:8px;transition:width .3s}
.msg{margin-top:16px;padding:14px;border-radius:10px;display:none;font-size:.9em;font-weight:500}
.ok{background:rgba(34,197,94,.1);color:#4ade80;border:1px solid rgba(34,197,94,.2)}
.err{background:rgba(239,68,68,.1);color:#f87171;border:1px solid rgba(239,68,68,.2)}
</style>
</head>
<body>
<div class="c">
<h1>Logi&ViktoRi</h1>
<p class="sub">Загрузчик прошивки</p>
<div class="drop" id="drop" onclick="document.getElementById('file').click()">
<div>Выберите .bin файл<br><small>или перетащите файл в это поле</small></div>
<div class="name" id="fname"></div>
<input type="file" id="file" accept=".bin">
</div>
<button id="btn" onclick="upload()" disabled>Прошить</button>
<div class="bar" id="bar"><div id="fill" class="ag-author"></div></div>
<div class="msg" id="msg"></div>
</div>
<script>
var f=null,drop=document.getElementById('drop'),fi=document.getElementById('file'),
    btn=document.getElementById('btn'),bar=document.getElementById('bar'),
    fill=document.getElementById('fill'),msg=document.getElementById('msg'),
    fname=document.getElementById('fname');

fi.onchange=function(){pick(this.files[0])};
drop.ondragover=function(e){e.preventDefault();drop.classList.add('over')};
drop.ondragleave=function(){drop.classList.remove('over')};
drop.ondrop=function(e){e.preventDefault();drop.classList.remove('over');if(e.dataTransfer.files.length)pick(e.dataTransfer.files[0])};

function pick(file){
  if(!file||!file.name.endsWith('.bin')){msg.className='msg err';msg.style.display='block';msg.textContent='Выберите .bin файл';return}
  f=file;fname.textContent=file.name+' ('+Math.round(file.size/1024)+' KB)';btn.disabled=false;
  msg.style.display='none';
}

function upload(){
  if(!f)return;
  var fd=new FormData();fd.append('firmware',f);
  var xhr=new XMLHttpRequest();
  btn.disabled=true;bar.style.display='block';fill.style.width='0%';msg.style.display='none';
  xhr.upload.onprogress=function(e){if(e.lengthComputable)fill.style.width=Math.round(e.loaded/e.total*100)+'%'};
  xhr.onload=function(){
    var ok=xhr.status===200;
    msg.className='msg '+(ok?'ok':'err');
    msg.style.display='block';
    msg.textContent=ok?'Прошивка загружена! Устройство перезагружается...':'Ошибка: '+xhr.responseText;
    if(ok)fill.style.width='100%';
    else btn.disabled=false;
  };
  xhr.onerror=function(){msg.className='msg err';msg.style.display='block';msg.textContent='Ошибка соединения';btn.disabled=false};
  xhr.open('POST','/upload');xhr.send(fd);
}
</script>
</body>
</html>
)rawliteral";

void handlePage() { server.send_P(200, "text/html", PAGE); }

void handleUpload() {
  server.send(200, "text/plain", updateOk ? "OK" : updateErr);
  delay(500);
  ESP.restart();
}

void handleUploadData() {
  HTTPUpload& upload = server.upload();

  if (upload.status == UPLOAD_FILE_START) {
    updateOk = false;
    updateErr = "";
#ifdef ESP32
    if (!Update.begin(UPDATE_SIZE_UNKNOWN)) {
#else
    uint32_t maxSize = (ESP.getFreeSketchSpace() - 0x1000) & 0xFFFFF000;
    if (!Update.begin(maxSize)) {
#endif
      updateErr = "Недостаточно места";
    }
  } else if (upload.status == UPLOAD_FILE_WRITE) {
    if (Update.write(upload.buf, upload.currentSize) != upload.currentSize) {
      updateErr = "Ошибка записи";
    }
  } else if (upload.status == UPLOAD_FILE_END) {
    if (Update.end(true)) {
      updateOk = true;
    } else {
      updateErr = "Произошла ошибка: " + String(Update.getError());
    }
  }
}

void setup() {
  WiFi.mode(WIFI_AP);
  WiFi.softAP("Updater_192.168.4.1");

  server.on("/", handlePage);
  server.on("/upload", HTTP_POST, handleUpload, handleUploadData);
  server.begin();
}

void loop() { server.handleClient(); }
