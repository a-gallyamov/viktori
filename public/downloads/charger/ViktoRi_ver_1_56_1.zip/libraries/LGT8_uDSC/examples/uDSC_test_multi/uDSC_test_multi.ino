#include <Arduino.h>
#include <LGT8_uDSC.h>

void setup() {
  Serial.begin(115200);
  uDSC_ON();
}

uint16_t volt = 2556;
uint16_t Vref = 65535;


void loop() {
  uDSC_op(reset_da);     // сброс DA = 0
  Serial.println(volt);
  uDSC_work(volt, Vref, mult_dxdy);  // выполнение операций над dx, dy. Запись результата в DA.
  Serial.print(" volt * vref = ");
  auto x = DA_Read_long();
  Serial.println(x);
  uDSC_divided_dy(1000, divided);  // выполнение операций с DA, dy
  Serial.print(" DA / 1000 = ");
  auto y = DA_Read_long();
  Serial.println(y);
  
  uDSC_op(reset_da);     // сброс DA = 0
  Serial.print(" DA = ");  
  Serial.println(DA_Read_long());
  
  DX_write(25600);
  Serial.print(" DX = ");  
  Serial.println(DX_Read());

  DY_write(25580);
  Serial.print(" DY = ");  
  Serial.println(DY_Read());
  
  uDSC_op(mult_dxdy);
  Serial.print(" x*y = ");  
  Serial.println(DA_Read_long());

  uDSC_work(16500, 1250, mult_dxdy);  // выполнение операций над dx, dy. Запись результата в DA.
  Serial.print(" DX = ");  
  Serial.println(DX_Read());
  Serial.print(" DY = ");  
  Serial.println(DY_Read());
  Serial.print(" x*y = ");  
  Serial.println(DA_Read_long());

  Vref -= 10;

  Serial.print("....");
  delay(3000);
}
