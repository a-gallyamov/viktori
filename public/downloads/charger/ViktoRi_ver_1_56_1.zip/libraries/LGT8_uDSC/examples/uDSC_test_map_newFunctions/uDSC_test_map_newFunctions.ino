#include <LGT8_uDSC.h>
/*
Реализация функции map на ускорителе uDSC/

Функция  map
int16_t map(long x, int16_t in_min, int16_t in_max, int16_t out_min, int16_t out_max) {  
  return (int16_t)((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min);
}
*/

/*
uint16_t uDSC_map(uint16_t x, uint16_t in_min, uint16_t in_max, uint16_t out_min, uint16_t out_max) {
  if (x >= in_max) return out_max;                                 // ограничение выхода
  if (x <= in_min) return out_min;                                 // ограничение выхода
  DSC_MUL((uint16_t)(x - in_min), (uint16_t)(out_max - out_min));  // DA = (x - in_min) * (out_max - out_min)
  DA_DIV((uint16_t)(in_max - in_min));                             // DA /= in_max
  return (uint16_t)DA_INC_get(out_min);                            // DA += out_min
}
*/
/*
int16_t uDSC_map_int(int16_t x, int16_t in_min, int16_t in_max, int16_t out_min, int16_t out_max) {
  if (x >= in_max) return out_max;                               // ограничение выхода
  if (x <= in_min) return out_min;                               // ограничение выхода
  DSC_MUL((int16_t)(x - in_min), (int16_t)(out_max - out_min));  // DA = (x - in_min) * (out_max - out_min)
  DA_DIV((int16_t)(in_max - in_min));                            // DA /= in_max
  return (int16_t)DA_INC_get(out_min);                           // DA += out_min
}
*/

void setup() {
  uDSC_ON();
  Serial.begin(115200);
  Serial.println("map function uDSC");
}

int16_t x = -30;
int16_t y;
int16_t z;

uint32_t t;  // время замера

void loop() { 
  Serial.print("x = ");
  Serial.println(x);

  t = micros();
  y = uDSC_map_int(x, -20, 20, -200, 200);

  t = micros() - t;
  Serial.print("uDSC_map = ");
  Serial.print(y);
  Serial.print(" time: ");
  Serial.println(t);


  t = micros();
  z = map(x, -20, 20, -200, 200);

  t = micros() - t;
  Serial.print("map = ");
  Serial.print(z);
  Serial.print(" time: ");
  Serial.println(t);

  x += 1;

  Serial.println("...");
  delay(1000);
}
