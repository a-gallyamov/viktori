/*
Тест деления чисел без знака 
*/

#include <LGT8_uDSC.h>

void setup() {
  Serial.begin(115200);
  uDSC_ON();
  Serial.println("Divided DA / DY");  
}

uint8_t v1 = 255;
uint16_t v2 = 25543;
uint32_t v3 = 2151230123;


void loop() {
    // выполнение операций деления da на dy. Запись результата в DA
  uDSC_divided_long(v1, 10, divided);
  Serial.print(v1);
  Serial.print(" / 10 = ");
  Serial.println(DA_Read_int());

  // и остатка от деления.  Запись результата в DA, DY.
  uDSC_divided_long(v1, 10, divided_rem);  
  Serial.print(v1);
  Serial.print(" % 10 = ");
  Serial.print(DA_Read_int());
  Serial.write('.');
  Serial.println(DY_Read());
  v1 -= 5;

  // выполнение операций деления da на dy. Запись результата в DA
  uDSC_divided_long(v2, 1000, divided);
  Serial.print(v2);
  Serial.print(" / 1000 = ");
  Serial.println(DA_Read_int());

  // и остатка от деления.  Запись результата в DA, DY.
  uDSC_divided_long(v2, 1000, divided_rem);  
  Serial.print(v2);
  Serial.print(" % 1000 = ");
  Serial.print(DA_Read_int());
  Serial.write('.');
  Serial.println(DY_Read());
  v2 -= 100;

  // выполнение операций деления da на dy. Запись результата в DA
  uDSC_divided_long(v3, 10000, divided);
  Serial.print(v3);
  Serial.print(" / 10000 = ");
  Serial.println(DA_Read_long());

  // и остатка от деления.  Запись результата в DA, DY.
  uDSC_divided_long(v3, 10000, divided_rem);  
  Serial.print(v3);
  Serial.print(" % 10000 = ");
  Serial.print(DA_Read_long());
  Serial.write('.');
  Serial.println(DY_Read());
  v3 -= 1000000;

  Serial.println(".....");
  delay(1000);
}
