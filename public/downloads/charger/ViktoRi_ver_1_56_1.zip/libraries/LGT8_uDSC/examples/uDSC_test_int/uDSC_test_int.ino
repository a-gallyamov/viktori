#include <LGT8_uDSC.h>
int32_t data_long;  // переменная для результата операций
int16_t data_int;   // переменная для результата операций
volatile int16_t i;
volatile int16_t j;


void setup() {
  Serial.begin(115200);
  uDSC_ON();  // Включить ускоритель вычислений uDSC
}

void loop() {
  i = 256;
  j = 500;
  // выполнение операций над dx, dy. Запись результата в da.
  // вычитание dx - dy = -244
  uDSC_work_intt(i, j, sub_dxdy);
  data_int = DA_Read_intt();  // считать результат 16 бит
  Serial.print("data_int: ");
  Serial.println(data_int);

  i = 256;
  j = -500;
  // вычитание dx - dy = 756
  uDSC_work_intt(i, j, sub_dxdy);
  data_long = DA_Read_intt();  // считать результат
  Serial.println(data_long);

  i = -256;
  j = 500;
  // сумма dx + dy = 244
  uDSC_work_intt(i, j, summ_dxdy);
  data_long = DA_Read_intt();  // считать результат
  Serial.println(data_long);

  i = -256;
  j = -500;
  // сумма dx + dy = -756
  uDSC_work_intt(i, j, summ_dxdy);
  data_long = DA_Read_intt();  // считать результат
  Serial.println(data_long);

  DA_write_long(2563245);  // записать число в регистр DA
  // выполнение операций с DA, dy
  // вычитание DA-DY=2526789
  uDSCdy(36456, sub_dy);        // уменьшение DA = DA - DY
  data_long = DA_Read_longt();  // считать результат
  Serial.println(data_long);

  i = -3269;
  j = 1000;
  // выполнение операций над dx, dy. Запись результата в da.
  // умножение dx * dy = -3269000
  uDSC_work_intt(i, j, mult_dxdy);
  data_long = DA_Read_longt();  // считать результат 16 бит
  Serial.println(data_long);


  i = -3269;
  j = -500;
  // выполнение операций над dx, dy. Запись результата в da.
  // умножение -dx * -dy = 1634500
  uDSC_work_intt(i, j, mult_dxdy);
  data_long = DA_Read_longt();  // считать результат 16 бит
  Serial.println(data_long);

  DA_shiftR(11);                // >> 12  = - 399
  data_long = DA_Read_longt();  // считать результат 16 бит
  Serial.println(data_long);

  i = 3269;
  j = -500;
  // выполнение операций над dx, dy. Запись результата в da.
  // умножение dx * -dy = -1634500
  uDSC_work_intt(i, j, mult_dxdy);
  // uDSC_work_int_yt(i, j, mult_dxdy);
  data_long = DA_Read_longt();  // считать результат 16 бит
  Serial.println(data_long);

  DA_shiftR(11);                // >> 12  = - 399
  data_long = DA_Read_longt();  // считать результат 16 бит
  Serial.println(data_long);

  Serial.println("..");
  delay(5000);
}
