#include "ADCaverage.h"

// инициализация, настройка АЦП
void ADC_init(const uint8_t divider, ADC_reference mode) {
  // вызывается обязательно
  ADC_enable();
  // Выбрать делитель частоты АЦП (2, 4, 8, 16, 32, 64, 128)
  ADC_setPrescaler(divider);
  // Выбрать источник опорного напряжения АЦП (ADC_1V1, ADC_AREF, ADC_VCC)
  ADC_setReference(mode);
}

 // занятость АЦП  - 1 свободен // нельзя трогать эту переменную из основной программы!!!
static int8_t adc_busy = -1;

bool ADCaverage::sample(void) {
  bool flag = false;
  // если ацп свободен
  if (adc_busy == (int8_t)(-1)) {
    // Аналоговый вход (ADC_A0-ADC_A7)
    setAnalogMux(pin);
    // ручной старт преобразования
    ADC_startConvert();
    // ацп занят
    adc_busy = (int8_t)(pin);
  } else if (adc_busy == (int8_t)(pin) and ADC_available()) {
    // суммируем скользящее среднее
    value += ((((int32_t)ADC_read() << AVER) - value) >> AVER);
    adc_busy = (int8_t)(-1);
    flag = true;
  }
  return flag;
}

// получить значение усреднения
uint16_t ADCaverage::getValue(void) { return (uint16_t)(value >> AVER); }

// рассчитать среднее напряжение БП
void VoltRead::compute(void) { volt = (uint16_t)(getValue() * _div); }

// рассчитать температуру термистора
void NTCRead::compute(void) {
  temp = NTC_compute((float)getValue(), baseDiv, b1, _tempBase);
}

// ввести сопротивление термистора в Ом
void NTCRead::setR1(uint16_t r1) {
  if (r1 > 0) {
    baseDiv = r1 / _rs2;
  }
}

// ввести сопротивление резистора в Ом
void NTCRead::setRS2(uint16_t rs2){
    if (rs2 > 0) {
      baseDiv = _r1 / rs2;
    }
}

// ввести базовую температуру (b1) термистора
void NTCRead::setTempBase(uint8_t temp){
      _tempBase = temp;
}

int8_t NTCRead::NTC_compute(float analog, float baseDiv, uint16_t B,
                            int8_t tempBase) {
  analog = baseDiv / ((float)(BITRATE - 1) / analog - 1.0f);
  analog = (log(analog) / B) + 1.0f / (tempBase + 273.15f);
  return (int8_t)(1.0f / analog - 273.15f);
}