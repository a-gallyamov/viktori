﻿#include "directADC_lgt8.h"

/* параметры помеченные знаком "default" вступают в силу после сброса МК до вызова соответствующих функций */

/* сервисные указатели на функции прерываний */
void (*adc_isr)();
void (*acomp_isr)();

/* выбор аналог входа */
/**
 * Sets the analog multiplexer for ADC input selection.
 *
 * @param mux The ADC input channel or reference voltage to select.
 *            Possible values:
 *            - ADC_A0 to ADC_A7: Analog input pins
 *            - ADC_1V1: Internal 1.1V reference
 *            - ADC_GND: Ground reference
 *            - ADC_4d5VDO: Internal 4.5V reference (LGT8F only)
 *            - ADC_1d5VDO: Internal 1.5V reference (LGT8F only)
 *            - ADC_DACO: DAC output (LGT8F only)
 *            - ADC_SENSOR: Temperature sensor (non-LGT8F)
 *
 * @note This function disables interrupts during the mux switch and re-enables them afterwards.
 */
void setAnalogMux(ADC_modes mux) {
    cli();
    switch (mux) {
        case ADC_A0:  // ADC_A0 (default)
            ADMUX &= ~((1 << MUX3) | (1 << MUX2) | (1 << MUX1) | (1 << MUX0));
            break;
        case ADC_A1:  // ADC_A1
            ADMUX &= ~((1 << MUX3) | (1 << MUX2) | (1 << MUX1));
            ADMUX |= (1 << MUX0);
            break;
        case ADC_A2:  // ADC_A2
            ADMUX &= ~((1 << MUX3) | (1 << MUX2) | (1 << MUX0));
            ADMUX |= (1 << MUX1);
            break;
        case ADC_A3:  // ADC_A3
            ADMUX &= ~((1 << MUX3) | (1 << MUX2));
            ADMUX |= ((1 << MUX1) | (1 << MUX0));
            break;
        case ADC_A4:  // ADC_A4
            ADMUX &= ~((1 << MUX3) | (1 << MUX1) | (1 << MUX0));
            ADMUX |= (1 << MUX2);
            break;
        case ADC_A5:  // ADC_A5
            ADMUX &= ~((1 << MUX3) | (1 << MUX1));
            ADMUX |= ((1 << MUX2) | (1 << MUX0));
            break;
        case ADC_A6:  // ADC_A6
            ADMUX &= ~((1 << MUX3) | (1 << MUX0));
            ADMUX |= ((1 << MUX2) | (1 << MUX1));
            break;
        case ADC_A7:  // ADC_A7
            ADMUX &= ~(1 << MUX3);
            ADMUX |= ((1 << MUX2) | (1 << MUX1) | (1 << MUX0));
            break;
        case ADC_SENSOR:  // ADC_SENSOR - термодатчик , только для Atmega328
            ADMUX &= ~((1 << MUX2) | (1 << MUX1) | (1 << MUX0));
            ADMUX |= (1 << MUX3);
            break;
        case ADC_1V1:  // ADC_1V1 - внутреннее опорное 1.1В // IVREF (LGT8F)
            ADMUX &= ~(1 << MUX0);
            ADMUX |= ((1 << MUX3) | (1 << MUX2) | (1 << MUX1));
            break;
        case ADC_GND:  // ADC_GND - подключить выход ацп к земле
            ADMUX |= ((1 << MUX3) | (1 << MUX2) | (1 << MUX1) | (1 << MUX0));
            break;
#if defined(__LGT8FX8P__)
        case ADC_A10:  // ADC_A10 - pin REF
            ADMUX &= ~(1 << MUX2);
            ADMUX |= ((1 << MUX3) | (1 << MUX1) | (1 << MUX0));
            break;
        case ADC_4d5VDO:  // ADC_4d5VDO - внутреннее 4/5
            ADMUX &= ~(1 << MUX1);
            ADMUX |= ((1 << MUX3) | (1 << MUX2) | (1 << MUX0));
            break;
        case ADC_1d5VDO:  // ADC_1d5VDO - внутреннее 1/5
            ADMUX &= ~((1 << MUX2) | (1 << MUX1) | (1 << MUX0));
            ADMUX |= (1 << MUX3);
            break;
        case ADC_DAC:  // ADC_DACO - вход ацп к выходу DAC
            ADMUX &= ~((1 << MUX3) | (1 << MUX2) | (1 << MUX1) | (1 << MUX0));
            ADMUX |= (1 << 4);  // MUX4
            break;
#endif
    }
    sei();
}

void ADC_enable(void) {  // включить ацп
    cli();
    ADCSRA |= (1 << ADEN);  // set adc enable
#if defined(__LGT8F__)
    sbi(ADCSRD, BGEN);  // установка бита
#endif
    sei();
}

void ADC_disable(void) {  // выключить ацп (default)
    cli();
    ADCSRA &= ~(1 << ADEN);  // clear adc enable
    sei();
}

/* выбор делителя частоты тактирования АЦП */
void ADC_setPrescaler(byte prescl) {
    cli();
    switch (prescl) {
        case 2:  // (defalut)
            ADCSRA &= ~((1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0));
            break;
        case 4:
            ADCSRA &= ~((1 << ADPS2) | (1 << ADPS0));
            ADCSRA |= (1 << ADPS1);
            break;
        case 8:
            ADCSRA &= ~(1 << ADPS2);
            ADCSRA |= ((1 << ADPS1) | (1 << ADPS0));
            break;
        case 16:
            ADCSRA &= ~((1 << ADPS1) | (1 << ADPS0));
            ADCSRA |= (1 << ADPS2);
            break;
        case 32:
            ADCSRA &= ~(1 << ADPS1);
            ADCSRA |= ((1 << ADPS2) | (1 << ADPS0));
            break;
        case 64:
            ADCSRA &= ~(1 << ADPS0);
            ADCSRA |= ((1 << ADPS2) | (1 << ADPS1));
            break;
        case 128:
            ADCSRA |= ((1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0));
            break;
        default:  // 32 (defalut)
            ADCSRA &= ~(1 << ADPS1);
            ADCSRA |= ((1 << ADPS2) | (1 << ADPS0));
            break;
    }
    sei();
}

/* Выбор опорного напряжения АЦП */
void ADC_setReference(ADC_reference ref) {
    cli();
#if defined(__LGT8F__)
    cbi(ADCSRD, REFS2);  // сброс бита REFS2
    switch (ref) {
        case ADC_VCC:  // напряжение питания AVCC
            ADMUX &= ~(1 << REFS1);
            ADMUX |= (1 << REFS0);
            break;
        case ADC_IVREF:  // AREF - внешнее опорное напряжение
            ADMUX &= ~((1 << REFS1) | (1 << REFS0));
            // станартные функции
            DACON = (DACON & 0x0C) | 0x1;
            if ((PMX2 & 0x2) == 0x2) {
                GPIOR0 = PMX2 & 0xfd;
                PMX2 = 0x80;
                PMX2 = GPIOR0;
            }
            break;
        case ADC_1V024:          // IVREF - внутреннее опорное напряжение
            sbi(ADCSRD, REFS2);  // установка бита REFS2
            ADCSRD &= ~((1 << IVSEL1) | (1 << IVSEL0));
            ADMUX |= ((1 << REFS1) | (1 << REFS0));
            VCAL = VCAL1;  // 1.024V
            break;
        case ADC_2V048:  // IVREF - внутреннее опорное напряжение
            ADMUX &= ~(1 << REFS0);
            ADMUX |= (1 << REFS1);
            ADCSRD &= ~((1 << IVSEL1));
            ADCSRD |= ((1 << REFS2) | (1 << IVSEL0));
            VCAL = VCAL2;  // 2.048V
            break;
        case ADC_4V096:  // IVREF - внутреннее опорное напряжение
            ADCSRD &= ~((1 << IVSEL0));
            ADCSRD |= ((1 << REFS2) | (1 << IVSEL1));
            ADMUX &= ~((1 << REFS1) | (1 << REFS0));
            VCAL = VCAL3;  // 4.096V
            break;
    }
#else
    switch (ref) {
        case ADC_1v1:  // 1v1
            ADMUX |= ((1 << REFS1) | (1 << REFS0));
            break;
        case ADC_AREF:  // ADC_AREF (default)
            ADMUX &= ~((1 << REFS1) | (1 << REFS0));
            break;
        case ADC_VCC:  // ADC_VCC
            ADMUX &= ~(1 << REFS1);
            ADMUX |= (1 << REFS0);
            break;
    }
#endif
    sei();
}

void ADC_setResolution(uint8_t res) {
    cli();
#if defined(__LGT8F__)
    analogReadResolution(res);
#else
    switch (res) {
        case 10:
            ADMUX &= ~(1 << ADLAR);  // right adjustment
            break;
        case 8:
            ADMUX |= (1 << ADLAR);  // left adjustment
            break;
    }
#endif
    sei();
}

/* Включить режим автозапуска АЦП и выбрать его источник. Внимание! Запуск преобразования начинается по ФРОНТУ (RISING) события */
void ADC_autoTriggerEnable(ADC_trigger trig) {
    cli();
    ADCSRA |= (1 << ADATE);  // autotrigger en
    switch (trig) {
        case FREE_RUN:  // free run (default)
            ADCSRB &= ~((1 << ADTS2) | (1 << ADTS1) | (1 << ADTS0));
            break;
        case ANALOG_COMP:  // analog_comp
            ADCSRB &= ~((1 << ADTS2) | (1 << ADTS1));
            ADCSRB |= (1 << ADTS0);
            break;
        case ADC_INT0:  // ADC_INT0
            ADCSRB &= ~((1 << ADTS2) | (1 << ADTS0));
            ADCSRB |= (1 << ADTS1);
            break;
        case TIMER0_COMPA:  // t0_compa
            ADCSRB &= ~(1 << ADTS2);
            ADCSRB |= ((1 << ADTS1) | (1 << ADTS0));
            break;
        case TIMER0_OVF:  // t0_ovf
            ADCSRB &= ~((1 << ADTS1) | (1 << ADTS0));
            ADCSRB |= (1 << ADTS2);
            break;
        case TIMER1_COMPB:  // t1_compb
            ADCSRB &= ~(1 << ADTS1);
            ADCSRB |= ((1 << ADTS2) | (1 << ADTS0));
            break;
        case TIMER1_OVF:  // t1_ovf
            ADCSRB &= ~(1 << ADTS0);
            ADCSRB |= ((1 << ADTS2) | (1 << ADTS1));
            break;
#if defined(__LGT8F__)
        case TIMER1_CAP_INPUT:  // t1_cap_input // Счетчик таймера 1 Событие захвата ввода
            ADCSRB |= ((1 << ADTS2) | (1 << ADTS1) | (1 << ADTS0));
            break;
#endif
    }
    sei();
}

// выключить автозапуск АЦП (defalut);
void ADC_autoTriggerDisable() {
    cli();
    ADCSRA &= ~(1 << ADATE);
    sei();
}

// подключить прерывание готовности АЦП
void ADC_attachInterrupt(void (*isr)()) {
    cli();
    adc_isr = *isr;
    ADCSRA |= (1 << ADIE);
    sei();
}

// выключить прерывание готовности АЦП (default)
void ADC_detachInterrupt() {
    cli();
    ADCSRA &= ~(1 << ADIE);
    sei();
}

void ADC_startConvert() {  // ручной запуск преобразования
    cli();
    ADCSRA |= (1 << ADSC);
    sei();
}

unsigned int ADC_read() {  // вернуть значение АЦП
    return ADC;
}

uint8_t ADC_read8(void) {  // вернуть 8-битное значение АЦП
    return ADCH;
}

boolean ADC_available() {        // проверить готовность АЦП
    if (ADCSRA & (1 << ADSC)) {  // if flag set - convert in process
        return false;
    } else {  // convert complete
        return true;
    }
}

unsigned int ADC_readWhenAvailable() {  // дождаться окончания текущего преобразования,склеить и вернуть результат
    while (ADCSRA & (1 << ADSC));
    return ADC;
}

uint8_t ADC_read8WhenAvailable(void) {
    while (ADCSRA & (1 << ADSC));
    return ADCH;
}

ISR(ADC_vect) {  // прерывание ацп
    (*adc_isr)();
}

#if defined(__LGT8F__)

#else
void ACOMP_attachInterrupt(void (*isr)(), AttachInterrupt source) {  // подключить прерывание ацп и выбрать условие вызова
    cli();
    acomp_isr = *isr;
    ACSR |= (1 << ACIE);  // set int bit
    switch (source) {
        case FALLING_TRIGGER:  // falling
            ACSR &= ~(1 << ACIS0);
            ACSR |= (1 << ACIS1);
            break;
        case RISING_TRIGGER:  // rising
            ACSR |= ((1 << ACIS1) | (1 << ACIS0));
            break;
        case CHANGE_TRIGGER:  // change (default)
            ACSR &= ~((1 << ACIS1) | (1 << ACIS0));
            break;
    }
    sei();
}

void ACOMP_detachInterrupt() {  // отключить прерывания компаратора (default)
    cli();
    ACSR &= ~(1 << ACIE);
    sei();
}

void ACOMP_enable() {  // включить компаратор после его отключения (default)
    cli();
    ACSR &= ~(1 << ACD);
    sei();
}

void ACOMP_disable() {  // выключить компаратор
    cli();
    ACSR |= (1 << ACD);  // set bit "analog comp disable"
    sei();
}

boolean ACOMP_read() {  // прочитать значение на выходе компаратора
    return ACSR & (1 << ACO);
}

void ACOMP_setInput(ACOMP_positive positive, ACOMP_negative negative) {
    cli();
    switch (positive) {
        case ADC_1_1:             // 1v1 - подключить его к источнику 1.1В
            ACSR |= (1 << ACBG);  // connect 1v1 to +in
            break;
        case ADC_AIN0:             // ADC_AIN0 (default) - отключить от источника 1.1В
            ACSR &= ~(1 << ACBG);  // disconnect 1v1
            break;
    }
    switch (negative) {
        case ADC_AIN1:               // ADC_AIN1 (default) - отключить выход от мультиплексора АЦП
            ADCSRB &= ~(1 << ACME);  // disable -in from mux
            break;
        case ANALOG_MUX:            // analog MUX - подключить выход к мультиплексору АЦП
            ADCSRB |= (1 << ACME);  // connetct -in to analog mux
            break;
    }
    sei();
}

ISR(ANALOG_COMP_vect) {  // прерывание компаратора
    (*acomp_isr)();
}
#endif

#if defined(__LGT8F__)
// подключение АЦП к мультиплексору (0) или к внутреннему дифференциальному усилителю (1)
void ADC_IN(bool difs) {
    cli();
    bitWrite(ADCSRC, DIFS, difs);
    sei();
}

// Дифференциальный усилитель
// Включить/отключить дифференциальный усилитель
void DAP_status(bool status) {
    cli();
    if (status)
        DAPCR |= (1 << DAPEN);
    else
        DAPCR &= ~(1 << DAPEN);
    sei();
}

// Установка неинвертирующего входа дифференциального усилителя
void DAP_setInvert(DAP_invert invert) {
    cli();
    switch (invert) {
        case DAP_A2:  // А2
            DAPCR &= ~((1 << DNS2) | (1 << DNS1) | (1 << DNS0));
            break;
        case DAP_A3:  // А3
            DAPCR &= ~((1 << DNS2) | (1 << DNS1));
            DAPCR |= (1 << DNS0);
            break;
        case DAP_A8:  // A8 отсутствует в QFP32
            DAPCR &= ~(1 << DNS1);
            DAPCR |= ((1 << DNS2) | (1 << DNS0));
            break;
        case DAP_A9:  // A9 отсутствует в QFP32
            DAPCR &= ~(1 << DNS2);
            DAPCR |= ((1 << DNS1) | (1 << DNS0));
            break;
        case DAP_SWC:  // пин 22 (SWС на торце платы)
            DAPCR &= ~((1 << DNS1) | (1 << DNS0));
            DAPCR |= (1 << DNS2);
            break;
        case DAP_APN5:  // неизвестно
            DAPCR &= ~(1 << DNS1);
            DAPCR |= ((1 << DNS2) | (1 << DNS0));
            break;
        case DAP_AGND:  // подключение к аналоговой земле
            DAPCR &= ~(1 << DNS0);
            DAPCR |= ((1 << DNS2) | (1 << DNS1));
            break;
        case DAP_OFF:
            DAPCR |= ((1 << DNS2) | (1 << DNS1) | (1 << DNS0));
            break;
    }
    sei();
}
// Установка неинвертирующего входа дифференциального усилителя
void DAP_setNoinvert(DAP_noinvert noinvert) {
    cli();
    switch (noinvert) {
        case DAP_MUX:  // DAP_MUX - мультиплексирование
            DAPCR &= ~((1 << DPS1) | (1 << DPS0));
            break;
        case DAP_A0:
            DAPCR &= ~(1 << DPS1);
            DAPCR |= (1 << DPS0);
            break;
        case DAP_A1:
            DAPCR &= ~(1 << DPS0);
            DAPCR |= (1 << DPS1);
            break;
        case DAP_GND:
            DAPCR |= ((1 << DPS1) | (1 << DPS0));
            break;
    }
    sei();
}

/**
 * Sets the gain for the Direct ADC Peripheral (DAP).
 *
 * @param gain The gain value to set. Valid values are 1, 8, 16, and 32.
 *             - 1: 1x gain
 *             - 8: 8x gain
 *             - 16: 16x gain
 *             - 32: 32x gain
 */
void DAP_gain(uint8_t gain) {
    cli();
    switch (gain) {
        case 1:  // 1x gain
            DAPCR &= ~((1 << GA1) | (1 << GA0));
            break;
        case 8:  // 8x gain
            DAPCR &= ~(1 << GA1);
            DAPCR |= (1 << GA0);
            break;
        case 16:  // 16x gain
            DAPCR &= ~(1 << GA0);
            DAPCR |= (1 << GA1);
            break;
        case 32:  // 32x gain
            DAPCR |= ((1 << GA1) | (1 << GA0));
            break;
    }
    sei();
}

// Выбор источника входного сигнала делителя напряжения 1/4, 1/5
void VDS_setInput(VDS_input input) {
    cli();
    switch (input) {
        case VDS_OFF:
            ADCSRD &= ~((1 << VDS2) | (1 << VDS1) | (1 << VDS0));
            break;
        case VDS_A0:
            ADCSRD &= ~((1 << VDS2) | (1 << VDS1));
            ADCSRD |= (1 << VDS0);
            break;
        case VDS_A1:
            ADCSRD &= ~((1 << VDS2) | (1 << VDS0));
            ADCSRD |= (1 << VDS1);
            break;
        case VDS_A4:
            ADCSRD &= ~((1 << VDS2));
            ADCSRD |= ((1 << VDS1) | (1 << VDS0));
            break;
        case VDS_A5:
            ADCSRD &= ~((1 << VDS1) | (1 << VDS0));
            ADCSRD |= (1 << VDS2);
            break;
        case VDS_VREF:
            ADCSRD &= ~(1 << VDS1);
            ADCSRD |= ((1 << VDS2) | (1 << VDS0));
            break;
        case VDS_VCC:
            ADCSRD &= ~(1 << VDS0);
            ADCSRD |= ((1 << VDS2) | (1 << VDS1));
            break;
    }
    sei();
}

/*
Калибровка смещения АЦП  (для дифференциального усилителя).
Включить АЦП и провести калибровку смещения АЦП.
*/
void Calibration_ADC_offset(void) {
    ADC_enable();                // включить АЦП
    ADC_setReference(ADC_VCC);  // установить референсный источник напряжения АЦП
    VDS_setInput(VDS_VCC);      // Выбор источника входного сигнала делителя напряжения

    setAnalogMux(ADC_4d5VDO);                // установить мультиплексор  на чтение сигнала  с делителя напряжения
    ADC_startConvert();                      // начать преобразование
    int16_t pVal = ADC_readWhenAvailable();  // дождаться окончания преобразования и считать значение
    sbi(ADCSRC, SPN);                        // вкл бит
    ADC_startConvert();                      // начать преобразование
    int16_t nVal = ADC_readWhenAvailable();  // дождаться окончания преобразования и считать значение
    OFR0 = (int8_t)((nVal - pVal) >> 1);

    setAnalogMux(ADC_1d5VDO);                 // установить мультиплексор  на чтение сигнала  с делителя напряжения
    ADC_startConvert();                       // начать преобразование
    nVal = (int16_t)ADC_readWhenAvailable();  // дождаться окончания преобразования и считать значение
    cbi(ADCSRC, SPN);                         // выкл бит
    ADC_startConvert();                       // начать преобразование
    pVal = (int16_t)ADC_readWhenAvailable();  // дождаться окончания преобразования и считать значение
    OFR1 = (int8_t)((nVal - pVal) >> 1);
    ADCSRC |= (1 << OFEN);  // включить функцию компенсации смещения АЦП
}

/*
Цифро Аналоговый Преобразователь (ЦАП, DAC).
*/
// выбор источника напряжения питания
void DAC_setReference(DAC_reference reference) {
    cli();
    switch (reference) {
        case DAC_AVCC:  // 0 - напряжение питания
            DACON &= ~((1 << DAVS1) | (1 << DAVS0));
            break;
        case DAC_AVREF:  // 1 - внешнее опорное напряжение
            DACON &= ~(1 << DAVS1);
            DACON |= (1 << DAVS0);
            break;
        case DAC_IVREF:  // 2 - внутреннее опорное напряжение
            DACON &= ~(1 << DAVS0);
            DACON |= (1 << DAVS1);
            break;
        case DAC_END:  // Отключить опорный источник ЦАП, а также выключить модуль ЦАП.
            DACON |= ((1 << DAVS1) | (1 << DAVS0));
            break;
    }
    sei();
}
// включить ЦАП
void DAC_status(bool status) {
    cli();
    if (status) {
        DACON |= (1 << DACEN);  // включить ЦАП
    } else {
        DACON &= ~(1 << DACEN);  // отключить ЦАП
    }
    sei();
}

// Выход ЦАП для управления доступом к внешнему порту - пин 4
void DAC_setOutput4(bool output) {
    cli();
    if (output) {
        DACON |= (1 << DAOE);  // вывод ЦАП на выход
    } else {
        DACON &= ~(1 << DAOE);  // вывод ЦАП на вход
    }
    sei();
}
// задать значение на выходе ЦАП
void DAC_setValue(uint8_t value) {
    DALR = value;  // задать значение на выходе ЦАП
}

// Компараторы 0 и 1
void ACOMP0_setNoinvert(ACOMP0_noinvert noinvert) {
    cli();
    switch (noinvert) {
        case COMP0_D6:
            C0SR &= ~(1 << C0BG);
            C0XR &= ~(1 << C0PS0);
            break;
        case COMP0_A6:
            C0SR &= ~(1 << C0BG);
            C0XR |= (1 << C0PS0);
            break;
        case COMP0_DAC:
            C0SR |= (1 << C0BG);
            C0XR &= ~(1 << C0PS0);
            break;
        case COMP0_OFF:
            C0SR |= (1 << C0BG);
            C0XR |= (1 << C0PS0);
            break;
    }
    sei();
}
void ACOMP0_setInvert(ACOMP0_invert invert) {
    cli();
    switch (invert) {
        case COMP0_D7:
            ADCSRB &= ~((1 << ACME01) | (1 << ACME00));
            break;
        case COMP0_MUX:
            ADCSRB |= (1 << ACME00);
            ADCSRB &= ~(1 << ACME01);
            break;
        case COMP0_DIF:
            ADCSRB &= ~(1 << ACME00);
            ADCSRB |= (1 << ACME01);
            break;
        case COMP0_LOW:
            ADCSRB |= ((1 << ACME00) | (1 << ACME01));
            break;
    }
    sei();
}

void ACOMP1_setNoinvert(ACOMP1_noinvert noinvert) {
    cli();
    switch (noinvert) {
        case COMP1_D13:
            C1SR &= ~(1 << C1BG);
            C1XR &= ~(1 << C1PS0);
            break;
        case COMP1_A6:
            C1SR &= ~(1 << C1BG);
            C1XR |= (1 << C1PS0);
            break;
        case COMP1_DAC:
            C1SR |= (1 << C1BG);
            C1XR &= ~(1 << C1PS0);
            break;
        case COMP1_OFF:
            C1SR |= (1 << C1BG);
            C1XR |= (1 << C1PS0);
            break;
    }
    sei();
}
void ACOMP1_setInvert(ACOMP1_invert invert) {
    cli();
    switch (invert) {
        case COMP1_A7:
            ADCSRB &= ~((1 << ACME11) | (1 << ACME10));
            break;
        case COMP1_D7:
            ADCSRB |= (1 << ACME10);
            ADCSRB &= ~(1 << ACME11);
            break;
        case COMP1_1d5:
            ADCSRB &= ~(1 << ACME10);
            ADCSRB |= (1 << ACME11);
            break;
        case COMP1_DIF:
            ADCSRB |= ((1 << ACME10) | (1 << ACME11));
            break;
    }
    sei();
}

void ACOMP0_status(bool status) {
    cli();
    if (status) {
        C0SR |= (1 << C0D);
    } else {
        C0SR &= ~(1 << C0D);
    }
    sei();
}
void ACOMP1_status(bool status) {
    cli();
    if (status) {
        C1SR |= (1 << C1D);
    } else {
        C1SR &= ~(1 << C1D);
    }
    sei();
}

boolean ACOMP0_read() {
    return C0SR & (1 << C0O);
}
boolean ACOMP1_read() {
    return C1SR & (1 << C1O);
}

void (*acomp0_isr)();
void (*acomp1_isr)();

ISR(ANALOG_COMP_0_vect) {  // прерывание компаратора
    (*acomp0_isr)();
}

ISR(ANALOG_COMP_1_vect) {  // прерывание компаратора
    (*acomp1_isr)();
}

void ACOMP0_attachInterrupt(void (*isr)(), ACOMPInterrupt source) {
    cli();
    acomp0_isr = isr;
    C0SR |= (1 << C0IE);  // разрешить прерывание
    switch (source) {
        case ALL_TRIGG:  // На каждый фронт
            C0SR &= ~((1 << C0IS1) | (1 << C0IS0));
            break;
        case FALLING_TRIGG:  // Падающий фронт
            C0SR &= ~(1 << C0IS0);
            C0SR |= (1 << C0IS1);
            break;
        case RISING_TRIGG:  // Нарастающий фронт
            C0SR |= ((1 << C0IS1) | (1 << C0IS0));
            break;
    }
    sei();
}

void ACOMP1_attachInterrupt(void (*isr)(), ACOMPInterrupt source) {
    cli();
    acomp1_isr = isr;
    C1SR |= (1 << C1IE);  // разрешить прерывание
    switch (source) {
        case ALL_TRIGG:  // На каждый фронт
            C1SR &= ~((1 << C1IS1) | (1 << C1IS0));
            break;
        case FALLING_TRIGG:  // Падающий фронт
            C1SR &= ~(1 << C1IS0);
            C1SR |= (1 << C1IS1);
            break;
        case RISING_TRIGG:  // Нарастающий фронт
            C1SR |= ((1 << C1IS1) | (1 << C1IS0));
            break;
    }
    sei();
}

void ACOMP0_detachInterrupt() {
    cli();
    C0SR &= ~(1 << C0IE);  // запретить прерывание
    sei();
}

void ACOMP1_detachInterrupt() {
    cli();
    C1SR &= ~(1 << C1IE);  // запретить прерывание
    sei();
}

// включить/отключить выход компаратора 0 на пин D2
void ACOMP0_setOutputD2(bool output){
    cli();
    if (output) {
        C0XR |= (1 << C0OE);
    } else {
        C0XR &= ~(1 << C0OE);
    }
    sei();
}

// включить/отключить выход компаратора 1 на ногу 6 чипа. Нога не подключена.
void ACOMP1_setOutputN6(bool output){
    cli();
    if (output) {
        C1XR |= (1 << C1OE);
    } else {
        C1XR &= ~(1 << C1OE);
    }
    sei();
}

// Гистерезис выхода компаратора включить/отключить
void ACOMP0_setHysteresis(bool hysteresis){
    cli();
    if (hysteresis) {
        C0XR |= (1 << C0HSYE);
    } else {
        C0XR &= ~(1 << C0HSYE);
    }
    sei();
}

void ACOMP1_setHysteresis(bool hysteresis){
    cli();
    if (hysteresis) {
        C1XR |= (1 << C1HSYE);
    } else {
        C1XR &= ~(1 << C1HSYE);
    }
    sei();
}

// управление цифровым фильтром компаратора включить/отключить
void ACOMP0_setFilter(bool filter){
    cli();
    if (filter) {
        C0XR |= (1 << C0FEN);
    } else {
        C0XR &= ~(1 << C0FEN);
    }
    sei();
}
void ACOMP1_setFilter(bool filter){
    cli();
    if (filter) {
        C1XR |= (1 << C1FEN);
    } else {
        C1XR &= ~(1 << C1FEN);
    }
    sei();
}

// Установка ширины цифрового фильтра компаратора (0, 32, 64, 96) us микросекунды
void ACOMP0_setFilterWidth(uint8_t width){
    cli();    
    switch (width) {
        case 0:   // отключить фильтрацию         
            C0XR &= ~((1 << C0FS1) | (1 << C0FS0));
            break;
        case 32:
            C0XR |= (1 << C0FS0);
            C0XR &= ~(1 << C0FS1);
            break;
        case 64:
            C0XR |= (1 << C0FS1);
            C0XR &= ~(1 << C0FS0);
            break;
        case 96:
             C0XR |= ((1 << C0FS1) | (1 << C0FS0));            
            break;
    }
    sei();
}
void ACOMP1_setFilterWidth(uint8_t width){
    cli();    
    switch (width) {
        case 0:   // отключить фильтрацию         
            C1XR &= ~((1 << C1FS1) | (1 << C1FS0));
            break;
        case 32:
            C1XR |= (1 << C1FS0);
            C1XR &= ~(1 << C1FS1);
            break;
        case 64:
            C1XR |= (1 << C1FS1);
            C1XR &= ~(1 << C1FS0);
            break;
        case 96:
             C1XR |= ((1 << C1FS1) | (1 << C1FS0));            
            break;
    }
    sei();
}

// Функция пробуждения от выхода компаратора 0,1
void ACOMP0_wakeup(bool wakeup){
    cli();
    if (wakeup) {
        C0XR |= (1 << C0WKE);
    } else {
        C0XR &= ~(1 << C0WKE);
    }
    sei();
}
void ACOMP1_wakeup(bool wakeup){
    cli();
    if (wakeup) {
        C1XR |= (1 << C1WKE);
    } else {
        C1XR &= ~(1 << C1WKE);
    }
    sei();
}

#endif