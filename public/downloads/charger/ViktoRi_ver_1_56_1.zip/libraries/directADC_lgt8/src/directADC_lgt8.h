﻿/*
    Библиотека для расширенного ручного управления АЦП и компаратором ATmega328.
    Доработки от ViktoRi:
    Для LGT8F328p добавлены расширенные функции ручного управления АЦП, ЦАП, два компаратора,
    встроенный дифференциальный усилитель, делитель напряжения.

    Документация:
    GitHub: https://github.com/GyverLibs/directADC
    Возможности:
    - Функции библиотеки позволяют получить доступ ко всем возможностям и режимам работы с АЦП
    - Ничего не урезано и не упрощено, доступен весь описанный в даташите функционал

    Egor 'Nich1con' Zaharov for AlexGyver, alex@alexgyver.ru
    https://alexgyver.ru/
    MIT License

    Версии:
    v1.1 - добавлены функции чтения 8 бит (спасибо Vitve4) https://github.com/AlexGyver/GyverLibs/pull/43
    v1.2 - добавлены функции для LGT8F328p от ViktoRi
    v1.3 - изменил название нумерованного списка ADC_modes, VDS_VREF, VDS_VCC
*/

#ifndef directADC_h
#define directADC_h
#include <Arduino.h>

#include "wiring_private.h"

/* For setAnalogMux() */
enum ADC_modes {
    ADC_A0,
    ADC_A1,
    ADC_A2,
    ADC_A3,
    ADC_A4,
    ADC_A5,
    ADC_A6,
    ADC_A7,
    ADC_SENSOR,  // ADC_SENSOR - термодатчик, только для Atmega328
    ADC_1V1,     // IVREF (LGT8F)
    ADC_GND,
#if defined(__LGT8FX8P__)
    ADC_A10,  // ADC_A10 - pin REF (25)
    ADC_4d5VDO,
    ADC_1d5VDO,
    ADC_DAC,
#endif
};

/* For ADC_setReference()*/
enum ADC_reference {
#if defined(__LGT8FX8P__)
    ADC_VCC,    // AVCC - напряжение питания
    ADC_IVREF,  // AREF - внешнее опорное напряжение
    ADC_1V024,  // IVREF - внутреннее опорное напряжение
    ADC_2V048,  // IVREF - внутреннее опорное напряжение
    ADC_4V096,  // IVREF - внутреннее опорное напряжение
#else
    ADC_1v1,
    ADC_AREF,
    ADC_VCC,
#endif
};

/* For autoTriggerEnable() */
enum ADC_trigger {
    FREE_RUN,
    ANALOG_COMP,
    ADC_INT0,
    TIMER0_COMPA,
    TIMER0_OVF,
    TIMER1_COMPB,
    TIMER1_OVF,
#if defined(__LGT8F__)
    TIMER1_CAP_INPUT,  // Счетчик таймера 1 Событие захвата ввода
#endif
};

/*For ACOMP_attachInterrupt()
выбрать условие вызова прерывания
*/
enum AttachInterrupt {
    FALLING_TRIGGER,
    RISING_TRIGGER,
    CHANGE_TRIGGER,  // (default)
};

/* For ACOMP_setPositiveInput()*/
enum ACOMP_positive {
    ADC_AIN0,
    ADC_1_1,
};

/* For ACOMP_setNegativeInput()*/
enum ACOMP_negative {
    ADC_AIN1,
    ANALOG_MUX,
};

extern void (*adc_isr)();
extern void (*acomp_isr)();

void setAnalogMux(ADC_modes mux);                               // Аналоговый вход (ADC_A0-ADC_A7)/ термодатчик (ADC_SENSOR)/ 1.1V (ADC_1V1)/ ADC_GND (default: ADC_A0)
void ADC_enable(void);                                              // Включить АЦП
void ADC_disable(void);                                             // Выключить АЦП (default)
void ADC_setPrescaler(byte prescl);                                 // Выбрать делитель частоты АЦП (2, 4, 8, 16, 32, 64, 128) // (default: 2)
void ADC_setReference(ADC_reference ref);                           // Выбрать источник опорного напряжения АЦП (ADC_1V1, ADC_AREF, ADC_VCC) // (default: ADC_AREF)
void ADC_setResolution(uint8_t res);                                // Выбрать разрядность АЦП (8, 10) // (default: 10)
void ADC_autoTriggerEnable(ADC_trigger trig);                       // Включить автозапуск АЦП и выбрать событие (FREE_RUN, ANALOG_COMP, ADC_INT0, TIMER0_COMPA, TIMER0_OVF, TIMER1_COMPB, TIMER1_OVF)
void ADC_autoTriggerDisable(void);                                  // Выключить автозапуск АЦП // (default)
void ADC_attachInterrupt(void (*isr)());                            // Включить прерывание готовности АЦП и выбрать функцию, которая будет при этом выполняться
void ADC_detachInterrupt(void);                                     // Выключить прерывание готовности АЦП // (default)
void ADC_startConvert(void);                                        // Ручной запуск преобразования
unsigned int ADC_read(void);                                        // Прочитать значение регистров АЦП (Вызов до окончания преобразования вернет неверный результат)
uint8_t ADC_read8(void);                                            // То же самое что ADC_read(), но возвращает 8-битный результат
boolean ADC_available(void);                                        // Проверить готовность преобразования АЦП
unsigned int ADC_readWhenAvailable(void);                           // Дождаться окончания текущего преобразования и вернуть результат
uint8_t ADC_read8WhenAvailable(void);                               // То же самое что ADC_readWhenAvailable(), но возвращает 8-битный результат
void ACOMP_attachInterrupt(void (*isr)(), AttachInterrupt source);  // Включить прерывание компаратора и выбрать при каком событии оно будет вызвано (FALLING_TRIGGER, RISING_TRIGGER, CHANGE_TRIGGER)
void ACOMP_detachInterrupt(void);                                   // Выключить прерывание компаратора // (default)
void ACOMP_enable(void);                                            // Включить компаратор // (default: Включен)
void ACOMP_disable(void);                                           // Принудительно выключить компаратор
boolean ACOMP_read(void);                                           // Прочитать значение на выходе компаратора
// Настроить куда подкл +Вход компаратора (ADC_1V1, ADC_AIN0) (default: ADC_AIN0 - pin 6)
// Настроить куда подкл -Вход компаратора (ADC_AIN1, ANALOG_MUX) (default: ADC_AIN1 - pin 7)
void ACOMP_setInput(ACOMP_positive positive, ACOMP_negative negative);

// делитель 2: 3.04 мкс (частота оцифровки 329 000 Гц)
// делитель 4: 4.72 мкс (частота оцифровки 210 000 Гц)
// делитель 8: 8.04 мкс (частота оцифровки 125 000 Гц)
// делитель 16: 15.12 мкс (частота оцифровки 66 100 Гц)
// делитель 32: 28.04 мкс (частота оцифровки 35 600 Гц)
// делитель 64: 56.04 мкс (частота оцифровки 17 800 Гц)
// делитель 128: 112 мкс (частота оцифровки 8 900 Гц)

#if defined(__LGT8F__)

// подключение АЦП к мультиплексору (0) или к внутреннему дифференциальному усилителю (1)
#define ADC_MUX 0
#define ADC_DIF 1
void ADC_IN(bool difs);

// Дифференциальный усилитель
// включить/отключить дифференциальный усилитель
void DAP_status(bool status);

enum DAP_invert {
    DAP_A2,    // 000 = ADC2 / APN0  A2
    DAP_A3,    // 001 = ADC3 / APN1  A3
    DAP_A8,    // 010 = ADC8 / APN2  A8 отсутствует в QFP32 (корпус 32 пин)
    DAP_A9,    // 011 = ADC9 / APN3  А9 отсутствует в QFP32
    DAP_SWC,   // 100 = PE0 / APN4   пин 22 (SWС на торце платы)
    DAP_APN5,  // 101 = APN5  - неизвестно!!! (возможно - мультиплексор)
    DAP_AGND,  // 110 = AGND  - подключение к аналоговой земле
    DAP_OFF,   // 111 = Off отключен Инвертирующий вход
};

enum DAP_noinvert {
    DAP_MUX,  // 00 = мультиплексор
    DAP_A0,   // 01 = ADC0 / APP0  A0
    DAP_A1,   // 10 = ADC1 / APP1  A1
    DAP_GND,  // 11 = AGND - подключение к аналоговой земле
};

// Установка инвертирующего входа дифференциального усилителя
void DAP_setInvert(DAP_invert invert);
// Установка неинвертирующего входа дифференциального усилителя
void DAP_setNoinvert(DAP_noinvert noinvert);
// Усиление дифференциальное усилителя - 1, 8, 16, 32
void DAP_gain(uint8_t gain);

// Делитель напряжения 1/4, 1/5
// Выбор источника входного сигнала делителя напряжения 1/4, 1/5
enum VDS_input {
    VDS_OFF,    // 000/111 = отключить
    VDS_A0,     // 001 = ADC0 - A0
    VDS_A1,     // 010 = ADC1 - A1
    VDS_A4,     // 011 = ADC4 - A4
    VDS_A5,     // 100 = ADC5 - A5
    VDS_VREF,  // 101 = AVREF внешнее опорное напряжение
    VDS_VCC,   // 110 = AVCC напряжение питания
};
void VDS_setInput(VDS_input input);

/*
Калибровка смещения АЦП (для дифференциального усилителя).
Включить АЦП и провести калибровку смещения АЦП.
*/
void Calibration_ADC_offset(void);


/*
Цифро Аналоговый Преобразователь (ЦАП, DAC).
Разрядность 8 бит (0-255).
Вывод аналогового сигнала на пин 4.
Подключение вывода ЦАП к мультиплексору АЦП, к аналововому компаратору 1 и 2 (нереверсивный вход).
*/
// Источник опорного напряжения ЦАП
enum DAC_reference {
    DAC_AVCC,   // 0 - напряжение питания  AVCC
    DAC_AVREF,  // 1 - внешнее опорное напряжение AVREF
    DAC_IVREF,  // 2 - внутреннее опорное напряжение IVREF (1.024, 2.048, 4.096)
    DAC_END,    // 3 - Отключить опорный источник ЦАП, а также выключить модуль ЦАП.
};

// если в качестве источника напряжения питания выбран DAC_IVREF - внутреннее опорное напряжение (1.024, 2.048, 4.096)
// то обязательно вызвать функцию ADC_setReference(ADC_reference ref);
// выбор источника опорного напряжения
void DAC_setReference(DAC_reference ref);
// включить/отключить ЦАП
void DAC_status(bool status);
// Выход ЦАП для управления доступом к внешнему порту - пин 4
void DAC_setOutput4(bool output);
// установить значение ЦАП
void DAC_setValue(uint8_t value);
/*
Настройка ЦАП выходной режим соотношения между величиной
напряжения ЦАП выходным напряжением DALR из:
VDAO = VREF * (DALR + 1) / 256
где:
VDAO - ЦАП выходные аналоговое напряжение
VREF - источник опорного напряжения ЦАП
*/

// Компаратор 0
enum ACOMP0_noinvert {
    COMP0_D6,   // AC0P D6
    COMP0_A6,   // ACXP A6
    COMP0_DAC,  // DAO ЦАП
    COMP0_OFF,  // Off отключен
};
enum ACOMP0_invert {
    COMP0_D7,   // ACXN D7
    COMP0_MUX,  // ADMUX мультиплексор
    COMP0_DIF,  // DFF0 выход дифф. усилителя
    COMP0_LOW,  // Off отключен
};

// Компаратор 1
enum ACOMP1_noinvert {
    COMP1_D13,  // AC1P D13
    COMP1_A6,   // ACXP A6
    COMP1_DAC,  // DAO ЦАП
    COMP1_OFF,  // Off отключен
};
enum ACOMP1_invert {
    COMP1_A7,   // AC1N A7
    COMP1_D7,   // ACXN D7
    COMP1_1d5,  // VD0  1d5 делитель напряжения 1/5
    COMP1_DIF,  // DFF0 выход дифф. усилителя
};

// Тип прерывания компаратора
enum ACOMPInterrupt {
    ALL_TRIGG,      // На каждый фронт
    FALLING_TRIGG,  // Падающий фронт
    RISING_TRIGG,   // Нарастающий фронт
};

void ACOMP0_setNoinvert(ACOMP0_noinvert noinvert);
void ACOMP0_setInvert(ACOMP0_invert invert);

void ACOMP1_setNoinvert(ACOMP1_noinvert noinvert);
void ACOMP1_setInvert(ACOMP1_invert invert);

// Включить/выключить компаратор
void ACOMP0_status(bool status);
void ACOMP1_status(bool status);

// Чтение состояния компаратора
boolean ACOMP0_read();
boolean ACOMP1_read();

// Включить прерывание компаратора и выбрать при каком событии оно будет вызвано
void ACOMP0_attachInterrupt(void (*isr)(), ACOMPInterrupt source);
void ACOMP1_attachInterrupt(void (*isr)(), ACOMPInterrupt source);

// Отключить прерывание компаратора
void ACOMP0_detachInterrupt();
void ACOMP1_detachInterrupt();

// включить/отключить выход компаратора 0 на пин D2
void ACOMP0_setOutputD2(bool output);
// включить/отключить выход компаратора 1 на ногу 6 чипа. Нога не подключена.
void ACOMP1_setOutputN6(bool output);

// Гистерезис выхода компаратора включить/отключить
void ACOMP0_setHysteresis(bool hysteresis);
void ACOMP1_setHysteresis(bool hysteresis);

// управление цифровым фильтром компаратора включить/отключить
void ACOMP0_setFilter(bool filter);
void ACOMP1_setFilter(bool filter);

// Установка ширины цифрового фильтра компаратора (0, 32, 64, 96) us микросекунды
void ACOMP0_setFilterWidth(uint8_t width);
void ACOMP1_setFilterWidth(uint8_t width);

// Функция пробуждения от выхода компаратора 0,1
void ACOMP0_wakeup(bool wakeup);
void ACOMP1_wakeup(bool wakeup);
#endif

#endif
