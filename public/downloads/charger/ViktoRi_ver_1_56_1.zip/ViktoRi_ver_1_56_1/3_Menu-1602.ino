// Меню версии 4.0 для дисплея LCD1602
void Menu1602() {
  if (bitRead(pam.MyFlag, ACTIVITI)) return;  // если флаг заряда установлен true то выйти иначе выполнять Menu
#if (TIME_LIGHT)
  disp.Light_high();  // включение подсветки
#endif
#if (POWPIN == 1)
  // Relay_on(true);  // включить сеть 220В
#endif
  butt.tick = 0;
  pam.Number = 1;
  Saved();                    // сохранить настройки
  uint8_t urovenmenu = 0;     // три уровня меню
  uint8_t main_menu = 0;      // номер пункта меню
  uint8_t point_setting = 0;  // номер пункта настроек
  bool printx = true;
  int8_t x = 0;
  ina.start();  // старт замеров INA
  do {
    // цикл меню
    switch (urovenmenu) {
      // основное меню urovenmenu
      case 0:
        point_setting = 0;
        // вывод меню
        if (printx) {
          printx = false;
          if (x) main_menu = (main_menu == 0 and x < 0) ? POINTMENU : ((main_menu == POINTMENU and x > 0) ? 0 : main_menu + x);  // реализация кругового меню
          lcd.clear();
          disp.printFromPGM((int)(&menuTxt[main_menu]));
          setCursory();
          switch (main_menu) {
            case 0:
              // профиль
              print_Capacity();
              Vout();                 // *Pr:0 Pb CA/Ca   *
              lcd.print(vkr.profil);  // *60Ah 12.60V(6)  *
              lcd.setCursor(5, 0);
              print_mode(TYPE_AKB);  // вывод типа акб
              break;
            case 1:
              print_Capacity();  // емкость акб
              break;
            case 2:
              print_mode(TYPE_AKB);  // вывод типа акб
              break;
            case 3:
              Vout();  // напряжение
              break;
            case 4:
              print_mode(MODE);  //  режим
              break;
          }
        }
        if (main_menu < POINTMENU) {
          if (butt.tick == OKCLICK) {
            urovenmenu = (main_menu < 5) ? 2 : 1;
            point_setting = 0;
            printx = true;
            break;
          }

          // удержание Пуск или Энкодера запускает заряд
          if (butt.tick == OKHELD) {
            bool ch = true;
            if (pam.typeAkb >= LI_ION) {
              switch (pam.Mode) {
                case CHARGE_ADDCHARGE:
                case BRANIMIR:
                case ADDCHARGE:
                case KTCycle:
                  ch = false;
                  break;
              }
            }
            if (ch) bitSet(pam.MyFlag, ACTIVITI);  // запустить работу режима, выйти из цикла меню
            else {
              lcd.clear();
              print_mode(TYPE_AKB);
              printSimb();  // пробел
              print_mode(MODE);
              setCursory();
              print_mode(ERROR);  // "error"
              Speaker(1000);      // функция звукового сигнала (время в миллисекундах)
              Delay(3000);
            }
            printx = true;
          }
        }
#ifdef BP_vc
        if (main_menu == POINTMENU and butt.tick == OKHELD) BP_vvcc();  // включить режим БП
#endif
        break;  // основное меню
      case 1:
        // urovenmenu 1 - подменю
        switch (main_menu) {
          case 0:
            Saved();  // сохранить настройки
            urovenmenu = 0;
            printx = true;
            break;
          case 1:
            // емкость акб
          case 2:
            // тип  акб
            // расчет при выборе емкости, типа и количества ячеек(напряжения) Акб
            calculate(1);  // расчет токов
          case 3:
            calculate(2);  // расчет напряжений
            urovenmenu = 0;
            printx = true;
            break;
          case 4:
            urovenmenu = 0;
            printx = true;
            break;
          case 5:
            // настройки
            if (printx) {
              printx = false;
              if (x) point_setting = (point_setting == 0 and x < 0) ? POINTSETTINGS : ((point_setting == POINTSETTINGS and x > 0) ? 0 : point_setting + x);  // реализация кругового меню
              lcd.clear();
              disp.printFromPGM((int)(&settings[point_setting]));
              setCursory();
              // вывод/изменение пунктов настроек
              Settings_point(point_setting, false, 0);
            }
            switch (butt.tick) {
              case STOPCLICK:
              case OKHELD:
                urovenmenu = 0;
                point_setting = 0;
                printx = true;
                Saved();  // сохранить настройки
                lcd.clear();
                print_mode(SETTING);  // "Settings"
                lcd.print(F(txt3));   // saved
                Delay(1000);
                break;
              case OKCLICK:
                urovenmenu = 2;
                printx = true;
                break;
            }
            break;
          case 6:
            // измерение сопротивления
#if (RESIST == 1)
            Resist();
            Saved();  // сохранить настройки
#endif
            urovenmenu = 0;
            printx = true;
            break;
          case 7:
            // статистика
            if (printx) {
              printx = false;
              if (x) point_setting = constrain_my(point_setting, 0, 3 + pam.Round, x);
              lcd.clear();
              Statistics_point(point_setting);  // вывод статистики
            }
            switch (butt.tick) {
              case OKCLICK:
              case STOPCLICK:
                urovenmenu = 0;
                point_setting = 0;
                printx = true;
                break;
            }
            break;
          case 8:
            // калибровка
            if (printx) {
              printx = false;
              lcd.clear();
#if (DISPLAYy == 2)
              if (x) point_setting = constrain_my(point_setting, 0, POINTCALIBRS, x);  // изменить пункт
              disp.printFromPGM((int)(&calibr[point_setting]));                        // вывести пункт
#endif

#if (DISPLAYy == 4)
              // вывести все пункты
              for (uint8_t i = 0; i <= POINTCALIBRS; i++) {
                lcd.setCursor(1, i);
                disp.printFromPGM((int)(&calibr[i]));
              }
              if (x) point_setting = constrain_my(point_setting, 0, POINTCALIBRS, x);
              // вывести указатель на пункт
              lcd.setCursor(0, point_setting);
              lcd.write('>');
#endif
            }
            switch (butt.tick) {
              case STOPCLICK:
              case OKHELD:
                urovenmenu = 0;
                point_setting = 0;
                printx = true;
                break;
              case OKCLICK:
                urovenmenu = 2;
                printx = true;
                break;
            }
            break;
        }
        break;
      case 2:
        //urovenmenu -  изменение параметров
        if (printx) {
          printx = false;
          setCursory();
          if (main_menu) lcd.write('<');
          switch (main_menu) {
            case 0:
              // выбор профиля
              vkr.profil = constrain_my(vkr.profil, 0, PROFIL, x);
#if defined(__LGT8FX8P__)
              lgt_eeprom_read_block(((uint8_t *)&pam), (uint16_t)(sizeof(pam) * vkr.profil + MEM_PAM), sizeof(pam));  // обновить значения в памяти
#else
              EEPROM.get((int)(sizeof(pam) * vkr.profil + MEM_PAM), pam);  // читаю из памяти значения
#endif

              print_Capacity();
              Vout();
              lcd.write('<');  // *Pr:<0>Pb CA/Ca  *
              lcd.print(vkr.profil);
              lcd.write('>');
              print_mode(TYPE_AKB);  // вывод типа акб
              ClearStr(4);           // очистить поле
              break;
            case 1:
              // емкость
              pam.Capacity = constrain_my(pam.Capacity, 1, 255, x);  // 255 максимальная емкость акб Ач
              lcd.print(pam.Capacity);
              ClearStr(4);  // очистить поле
              break;
            case 2:
              // выбор типа аккумулятора
              pam.typeAkb = constrain_my(pam.typeAkb, 0, 8, x);  // девять типов акб
              print_mode(TYPE_AKB);                              // вывод типа акб
              ClearStr(4);                                       // очистить поле
              break;
            case 3:
              // напряжение, количество ячеек
              pam.Voltage = constrain_my(pam.Voltage, 1, 26, x);  // 26 - максимальное количество ячеек акб
              while ((bat.Volt(volt_cell) > POWERINT) and (pam.Voltage > (uint8_t)1)) pam.Voltage--;
              print_mode(VOLTAGE);  // 12.6V
              lcd.write('(');
              lcd.print(pam.Voltage);
              lcd.write(')');
              ClearStr(2);  // очистить поле
              break;
            case 4:
              // выбор режима
              pam.Mode = constrain_my(pam.Mode, 0, POINTMODE, x);
              print_mode(MODE);
              ClearStr(10);  // очистить поле
              break;
            case 5:
              // настройки
              Settings_point(point_setting, true, (int16_t)x);  // вывод/изменение пунктов настроек
              // сброс настроек по умолчанию
              if (point_setting == POINTSETTINGS) {
                urovenmenu = 0;
                main_menu = 0;
                printx = true;
              }
              if (butt.tick == OKCLICK or butt.tick == STOPCLICK or point_setting == SYSPARAM) {
                urovenmenu = 1;
                printx = true;
              }
              break;
            case 8:
              // калибровка
              Korrect(point_setting);
              //Saved();  // сохранить настройки
              urovenmenu = 1;
              printx = true;
              break;
          }
          if (main_menu and main_menu < POINTSETTINGS - 2) {
            lcd.setCursor(DISPLAYx - 1, 1);
            lcd.write('>');
          }
        }

        if (main_menu < 5 and (butt.tick == OKCLICK or butt.tick == STOPCLICK)) {
          urovenmenu = 1;
          printx = true;
        }
        break;  // изменение параметров urovenmenu = 2
    }
    // -- меню
    x = 0;
    // ожидание действий пользователя
    do {
      sensor_survey();
      if (get_second()) {
        // если прошла секунда
        // вывод на дисплей напряжения, тока, температуры раз в одну секунду
        if (main_menu == POINTMENU) {
          // *24.12V 25C 20C   *
          // *12.652V 0.061A  *
#if (VOLTIN == 1)
          // напряжение от БП
          setCursorx();
          PrintVA(adc_v.volt);
#endif
#if (SENSTEMP1 or SENSTEMP2)
          lcd.setCursor(7, 0);
          print_tr();  // температура транзистора или акб
#endif
#if (POWPIN == 1)
          if (timer_bp) {
            lcd.setCursor(DISPLAYx - 2, 0);
            lcd.print(timer_bp);  // вывод времени до отключения ЗУ
          }
#endif
          setCursory();
          PrintVA(ina.voltsec, ina.ampersec, 0, 0, 3);  // *12.361V -0.253A *
          // print_memoryFree(); // вывод свободной оперативки
        }
#if (TIME_LIGHT)
        // отключение подсветки через 3 минуты, при отсутствии питания если разрешено отключение
        disp.Light_power();
#endif
      }
      // --- выполнить раз в секунду

    } while (!butt.tick and !printx);
    // --- ожидание действий пользователя

    if (butt.tick <= 1) x = butt.tick;
    printx = true;
  } while (BitIsClear(pam.MyFlag, ACTIVITI));  // цикл меню

  if (pam.Mode != DISCHARGE) Res_mem_char();                            // сброс значений заряда
  if (pam.Mode == DISCHARGE or pam.Mode == KTCycle) Res_mem_dischar();  // сброс значений разряда
  if (pam.Mode == KTCycle) Res_ktc();                                   // очистить память КТЦ
  if (pam.Mode == BRANIMIR) pam.Round = 3;                              // для Бранимира минимум 3 раунда
  regim_end = beg;
  if (pam.Round < 1) pam.Round = 1;
#if defined(__LGT8FX8P__)
  lgt_eeprom_update_byte(MEM_ROUNDi, pam.Round);
#else
  EEPROM.update(MEM_ROUNDi, pam.Round);  // сохранить количество циклов
#endif
}
