#if (DISCHAR == 1)
//Функция разряда аккумулятора
void Discharge() {
  //вывод режима, напряжения и тока заряда/разряда
  PrintVA(pam.Volt_discharge, pam.Current_discharge, 0, 0, 2);  // напряжения и тока разряда
  printCykl();                                                  // вывод количества циклов
  Freq(get_epprom_servise(FREQDISCHAR));                        // установить частоту работы разрядного модуля (4 кГц по умолчанию)
  const uint16_t s1 = ina.voltsec;                              // текущее наряжение акб;
  uint8_t n_disp = 0, ns_disp = 0;
  bool dischar = true;  // разряд включен

  uint8_t time_millis = 0;
  Tyme tyme;
  tyme.local = pam.Time_discharge;

 // const uint16_t volt_crash = pam.Volt_discharge - (pam.Volt_discharge >> 6);       // дополнительная защита напряжения
 // const int16_t curr_crash = pam.Current_discharge + (pam.Current_discharge >> 4);  // дополнительная защита тока

  ina.start();  // старт замеров INA
#if (POWPIN == 1)
  Relay_on(LOW);  // отключить реле
#endif
#if (FAN and KULDISCHAR)
  kul.ONonse(true);  // запустить кулер
#endif
  Delay(4000);
#if (POWPIN == 1)
  // если ток разряда менее тока ЗУ*2 реле 220В включится
  if (pam.Current_discharge_min <= (abs(ina.curr_aver) << 1)) Relay_on(HIGH);  // включить реле
#endif

  uint16_t time10 = 600;  // выполнить раз в 600 сек (10 мин)
  start_second_usr(); // старт счета секунд
  dcdc.start(DCDC_DISCHARGE);
  dcdc.begin(pam.Volt_discharge, pam.Current_discharge);  // задает напряжение и ток разряда
  // цикл разряда 35 часов максимум (35*60*60=126000 сек)
  while (dischar and bitRead(pam.MyFlag, ACTIVITI) and pam.Time_discharge < 126000) {
    sensor_survey();  // опрос кнопок, INA226, напря. от БП., контроль dcdc.

    if (butt.tick) {
      // если кнопка нажата
      switch (butt.tick) {
        case OKHELD:                       // удержать энкодер
        case STOPHELD:                     // удержать Стоп
          bitClear(pam.MyFlag, ACTIVITI);  // завершить разряд
          break;
        case RIGHT:             // энкодер вправо
        case LEFT:              // энкодер влево
          n_disp++;             // окно отображения
          ns_disp = TIME_DISP;  // время отображения сек
          lcd.clear();
          break;
      }
    }

    if (get_second()) {      
      time_millis = 5;
    }

    // если прошла секунда
    if (time_millis) {
      switch (time_millis) {
        case 5:
          pam.Ah_discharge += aw_ch((int32_t)abs(ina.ampersec));  // расчет ампер/часов
          pam.Wh_discharge += aw_ch(ina.getsPower());             // расчет ватт/часов
          tyme.cal_real_tm();                                     // рассчитать количество всех секунд разряда
          pam.Time_discharge = tyme.real_tm;
          break;
        case 4:
          {
            int16_t ampsec = abs(ina.ampersec);
            if (ina.volt_aver <= pam.Volt_discharge and ampsec <= pam.Current_discharge_min) dischar = false;  // напряжение уменьшилось до установленного и ток уменьшился до установленного то завершить разряд
          }
          break;
        case 3:
          // вывод на дисплей 1602
#if (DISPLAYy == 2)
          switch (n_disp) {
              // вывод на дисплей
            case 0:
              // экран 0 // вывод текущих значений напряжения, тока. Вывод Ватт-часов.
              Display_print(pam.Ah_discharge, pam.Time_discharge, map_my(ina.voltsec, pam.Volt_discharge, s1, 0, 100), false);  // вывод на дисплей
              break;
            case 1:
              // экран 1 // вывод средних значений напряжения, тока. Вывод Ватт-часов.
              setCursorx();
              print_mode(MODE);
              printSimb();
              printCykl();
              printSimb();
              lcd.print(dcdc.getTok());  // вывод значения ШИМ заряда
              setCursory();
              PrintVA(0, 0, 0, pam.Wh_discharge);
              lcd.print(map_my(ina.voltsec, pam.Volt_discharge, s1, 0, 100));
              lcd.write('%');
              printSimb();
#if (SENSTEMP1 or SENSTEMP2)
              print_tr();  // температура транзистора или акб
#endif
                // print_memoryFree(); // вывод свободной оперативки
              if (ns_disp) ns_disp--;
              else n_disp = 0;
              break;
              // *Discharge C1 N1 *
              // *45.25Wh 45%     *
            default:
              n_disp = 0;
              break;
          }
// вывод на дисплей 2004 или 1604
#elif (DISPLAYy == 4)
          // вывод на дисплей
          switch (n_disp) {
            case 0:
              // экран 0  вывод текущих значений
              Display_print(pam.Ah_discharge, pam.Wh_discharge, pam.Time_discharge, temp_Q1, map_my(ina.voltsec, pam.Volt_discharge, s1, 0, 100));
              break;
            case 1:
              // экран 1
              setCursorx();
              print_mode(MODE);
              printSimb();
              printCykl();
              setCursory();
#if (SENSTEMP1 or SENSTEMP2)
              print_tr();  // температура транзистора или акб
#endif
              if (ns_disp) ns_disp--;
              else n_disp = 0;
              break;
            default:
              n_disp = 0;
              break;
          }
#endif
          break;

        case 2:
#if (TIME_LIGHT)
          disp.Light_low();  // отключение подсветки через 3 минуты, если разрешено отключение
#endif
          break;
        case 1:
#if (GUARDA0)
          Guard();  // принудительная блокировка модуля защиты при напряжении заряда или разряда акб менее 5 Вольт.
#endif
#if (LOGGER)
#if (LOGGER == 4)
          Sout.create_advanced(-pam.Ah_discharge, 0, 0, pam.Time_discharge);
#else
          Sout.create(-pam.Ah_discharge);
#endif
#endif
          // выполнить раз в 10 мин
          if (--time10 == 0) {
            time10 = 600;
            Saved();  // сохранить настройки
          }
          break;
      }
      time_millis--;
    }
    // выполнить раз в секунду
  }
  // цикл разряда
  dcdc.Off();  // отключить заряд, разряд.
#if (GUARDA0)
  gio::low(PROTECTBLOCK);
#endif
#if (FAN and KULDISCHAR)
  kul.ONonse(false);  // автоматический режим кулера
#endif
  Saved();  // сохранить настройки
#if (POWPIN == 1)
  Relay_on(true);  // включить сеть 220В
#endif
}
// Функция разряда аккумулятора
#endif

#if (RESIST == 1)
// Функция измерения сопротивления
void Resist() {
  if (ina.voltsec < 2000) {
    print_mode(ERROR);  // "error"
    Delay(1000);
    return;
  }
  ina.start();                            // старт замеров INA
  Freq(get_epprom_servise(FREQDISCHAR));  // установить частоту работы разрядного модуля (4 кГц по умолчанию)
  bitSet(pam.MyFlag, ACTIVITI);           // старт работы режима
  dcdc.start(DCDC_DISCHARGE);             // старт разряда
  dcdc.Smooth_off(LOW);                   // отключить плавный пуск
  dcdc.begin((ina.voltsec >> 1), 800);    // задает напряжение и ток разряда
  uint16_t vlt = ina.voltsec;
  uint8_t timer = 60;  // время первого замера сек.
  do {
    //выполнять 10 сек
    sensor_survey();  // опрос кнопок, INA226, напря. от БП., контроль dcdc.
    if (butt.tick == OKHELD or butt.tick == STOPCLICK) {
      dcdc.Off();  // отключить заряд, разряд.
      bitClear(pam.MyFlag, ACTIVITI);
      return;
    }
    if (get_second()) {
      // если прошла секунда вывод на дисплей
      setCursory();
      PrintVA(ina.voltsec, abs(ina.ampersec), 0, 0, 3);  // *12.361V 3.555A  *
      lcd.setCursor(DISPLAYx - 2, 0);
      lcd.print(--timer);
      printSimb();
      if (difference(vlt, ina.voltsec) <= 1) break;  // стабилизация напряжения до 1мВ/сек
      vlt = ina.voltsec;
    }
  } while (timer);
  int16_t I[2]{ abs(ina.ampersec), 0 };  // сохранить ток
  uint16_t U[2]{ ina.voltsec, 0 };       // сохранить напряжение
  dcdc.begin((ina.voltsec >> 1), 4000);  // задает напряжение и ток разряда  - в 5 раз больше
  Delay(1000);                           // ожидание // 3000
  I[1] = abs(ina.ampersec);              // сохранить ток
  U[1] = ina.voltsec;                    // сохранить напряжение
  dcdc.Off();                            // отключить заряд, разряд.
  bitClear(pam.MyFlag, ACTIVITI);
  setCursory();
  PrintVA(U[1], I[1], 0, 0, 3);  // *12.36V 3.55A    *
  ClearStr(4);
  Delay(4000);                                                               // ожидание 4 сек
  float r = ((float)(U[0] - U[1]) / (float)(I[1] - I[0]));                   // расчитать внутренее сопротивление аккумулятора
  pam.Resist_2 = (uint16_t)((1.0 / (float)(U[0] - U[1]) / r) * 1000 + 0.5);  // расчет пускового тока
  r *= 1000;                                                                 // перевод в миллиОм
  r *= 0.215;                                                                // подстроечный коэффициент сопротивления

  pam.Resist_1 = (uint16_t)(r * 100);
  setCursory();
  lcd.print(r, 2);
  lcd.print(F("mOm "));
  lcd.print(pam.Resist_2);
  lcd.write('A');
  ClearStr(4);
  Delay(7000);  // ожидание
}
#endif