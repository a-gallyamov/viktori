#include <Arduino.h>
#include "system.h"
#if defined(__LGT8FX8P__)
//#define LGT8_TIMER3  // использовать таймер 3 в программе (раскомментировать если нужен)
// таймер 3 настроен на 1 секунду с прерыванием и подсчетом секунд пользователя при установке флага.
// таймер 3 пока не используется
#include "system_lgt8.h"
#include <LGT8_uDSC.h>
#endif
#include <microWire.h>
#include "1_User_Setup.h"
#include "AllFunctions.h"
#include <EEPROM.h>
#include "2_menu.h"

#if (LOGGER == 1)
// буфер отправки - байт
#define MU_TX_BUF 16
#elif (LOGGER == 2 or LOGGER == 3 or LOGGER == 4)
// буфер отправки - байт
#define MU_TX_BUF 30
#else
// буфер отправки - байт
#define MU_TX_BUF 4
#endif
// буфер приема - байт
#define MU_RX_BUF 4
#if (LOGGER == 2 or LOGGER == 3)
// подключить Print.h
#define MU_PRINT
#endif
#include <MicroUART.h>
MicroUART mSerial;


// флаги глобальные
#define POWERHIGH 0  // напряжение блока питания не превышает POWER_MAX (true - напряжения питания в норме)
#define POWERON 1    // питание от БП поступает
#define TR_Q1_ERR 2  // превышена температура на силовом транзисторе
//#define DISP_LIGHT 3   // разрешено отключать подсветку дисплея
#define RELEY_OFF 4  // разрешено отключать реле
#define TEMP_AKB 5   // температура акб (true - в норме)
#define SECOND 6     // флаг секунды

uint8_t flag_global = 0b00110011;

#if (POWPIN == 1)
uint16_t timer_bp = 0;
#endif

// флаг секунды
bool get_second(void) {
  if (bitRead(flag_global, SECOND)) {
    bitClear(flag_global, SECOND);
    return true;
  }
  return false;
}

#pragma pack(push, 1)
// 9 байт
struct Intls {
  uint8_t GlobFlag;  // Q1 - состояние силового транзистора Q1 - рабочий/пробит
  uint8_t Ohms;      // кооффициент коррекции напряжения 0-255 (сопротивление линии до акб)
  uint8_t profil;    // текущий профиль 0-9
  uint16_t Vref;     // коэффициент для калибровки напряжения БП - VKORRECT
  uint16_t shunt;    // значение сопротивления шунта (1000 это 10.00 мОм)
  uint16_t inaKoof;  // коэффициент для калибровки напряжения INA226
} vkr;
#pragma pack(pop)

#pragma pack(push, 1)
// 81 байт
struct MyStrukt {
  uint8_t MyFlag;                  // - (Precharge,Branimir,Oscillation,Charge)     bool Oscillation;   // oscillation bool  1 бит - режим качели (ассиметричный заряд)  bool branimir = true;
  uint8_t typeAkb;                 // - тип аккумулятора (4)
  uint8_t Mode;                    // - режим заряда (4)
  uint8_t Capacity;                // - емкость аккумулятора
  uint8_t Voltage;                 // - количество ячеек аккумулятора
  uint8_t Number;                  // - номер
  uint8_t Round;                   // - текущий круг
  int32_t Ah_charge;               // - емкость заряда - миллиампер/часы / 1000000
  int32_t Wh_charge;               // - емкость заряда - милливатт/часы / 1000000
  uint32_t Time_charge;            // - время заряда - секунды
  uint16_t Volt_charge;            // - напряжение заряда - миливольт / 1000 (макс 65.535 Вольт)
  uint16_t Volt_decrCur;           // - Напряжение при котором начинает снижаться ток
  uint16_t Volt_add_charge;        // - напряжение дозаряда - миливольт / 1000 (макс 65.535 Вольт)
  int16_t Current_charge;          // - ток заряда - миллиампер / 1000 (макс 32,767 Ампер)
  int16_t Current_add_charge;      // - ток дозаряда - миллиампер / 1000 (макс 32,767 Ампер)
  int16_t Current_charge_min;      // - ток завершения заряда - миллиампер / 1000 (макс 32,767 Ампер)
  int16_t Current_add_charge_min;  // - ток завершения дозаряда - миллиампер / 1000 (макс 32,767 Ампер)
  uint8_t Time_charge_h;           // - время заряда, часы
  uint8_t Time_add_charge_h;       // - время дозаряда, часы
  uint16_t Volt_discharge;         // - напряжение разряда - миливольт / 1000 (макс 65.535 Вольт)
  int16_t Current_discharge;       // - ток разряда - миллиампер / 1000 (макс 32,767 Ампер)
  int16_t Current_discharge_min;   // - ток завершения разряда - миллиампер / 1000 (макс 32,767 Ампер)
  uint16_t Volt_buffer;            // - напряжение буферного (выравнивающего режима) - миливольт / 1000 (макс 65.535 Вольт)
  uint16_t Volt_storage;           // - напряжение хранения - миливольт / 1000 (макс 65.535 Вольт)
  uint16_t Volt_pre_charge;        // - напряжение предзаряда (для сильно разр. аккумул) - миливольт / 1000 (макс 65.535 Вольт)
  int16_t Current_pre_charge;      // - ток предзаряда (для сильно разр. аккумул) - миллиампер / 1000 (макс 32,767 Ампер)
  int32_t Ah_discharge;            // - емкость разряда - миллиампер/часы / 1000000
  int32_t Wh_discharge;            // - емкость разряда - милливатт/часы / 1000000
  uint32_t Time_discharge;         // - время разряда - миллисекунды
  int32_t Ah_addcharge;            // - емкость дозаряда до напряжения аккумулятора - миллиампер/часы / 1000000
  int32_t Wh_addcharge;            // - емкость дозаряда до 12 вольт - милливатт/часы / 1000000
  uint32_t Time_addcharge;         // - время дозаряда - миллисекунды
  uint16_t Resist_1;               // - внутренее сопротивление аккумулятора - миллиОм / 100 - до
  uint16_t Resist_2;               // - пусковой ток
  uint16_t period_charge;          // - период заряда - сек
  uint16_t period_discharge;       // - период разряда - сек
} pam;
#pragma pack(pop)

// более сильная функция для замены в библиотеке EncButton
uint32_t EB_uptime() {
  return (uint32_t)millis_my();
}
//void setEncType(uint8_t type);
#define EB_DEB_TIME 50     // таймаут гашения дребезга кнопки (кнопка)
#define EB_CLICK_TIME 500  // таймаут ожидания кликов (кнопка)
#define EB_HOLD_TIME 1000  // таймаут удержания (кнопка)
#define EB_STEP_TIME 200   // таймаут импульсного удержания (кнопка)
#define EB_FAST_TIME 30    // таймаут быстрого поворота (энкодер)
#define EB_NO_CALLBACK     // отключить обработчик событий attach (экономит 2 байта оперативки)
#define EB_NO_COUNTER      // отключить счётчик энкодера [VirtEncoder, Encoder, EncButton] (экономит 4 байта оперативки)
//#define EB_NO_BUFFER     // отключить буферизацию энкодера (экономит 2 байта оперативки)
#include <EncButton.h>  // Библиотека энкодера и кнопок
#if (ENCBUTT == 0)
// 0 - только энкодер
EncButtonT<ENC_S2, ENC_S1, ENC_KL> enc(INPUT_PULLUP, INPUT_PULLUP);  // энкодер с кнопкой
#elif (ENCBUTT == 1)
// 1 - только кнопки
ButtonT<PUSK> OK(INPUT_PULLUP);      // кнопка - Пуск
ButtonT<MINUS> Minus(INPUT_PULLUP);  // кнопка - Минус
ButtonT<PLUS> Plus(INPUT_PULLUP);    // кнопка - Плюс
ButtonT<STOP> Stop(INPUT_PULLUP);    // кнопка - Стоп
#elif (ENCBUTT == 2)
// 2 - энкодер + OK + Stop
EncButtonT<ENC_S2, ENC_S1, ENC_KL> enc(INPUT_PULLUP, INPUT_PULLUP);
ButtonT<PUSK> OK(INPUT_PULLUP);
ButtonT<STOP> Stop(INPUT_PULLUP);
#elif (ENCBUTT == 3)
// 3 - энкодер + все кнопки
EncButtonT<ENC_S2, ENC_S1, ENC_KL> enc(INPUT_PULLUP, INPUT_PULLUP);
ButtonT<PUSK> OK(INPUT_PULLUP);
ButtonT<MINUS> Minus(INPUT_PULLUP);
ButtonT<PLUS> Plus(INPUT_PULLUP);
ButtonT<STOP> Stop(INPUT_PULLUP);
#endif

#include "LiquidCrystal_I2C.h"  // Библиотека дисплея
LiquidCrystal_I2C lcd(ADDRDISP, DISPLAYx, DISPLAYy);

// напряжение одной ячейки аккумулятора, мВ (умножить на 10)
//{ Pb Ca/Ca, Pb Ca+, Pb Sur, Pb AGM, Pb Gel, Li-ion, LiFePo4, LiTit, NiCd/Mh }
const uint16_t bt_volt[4][9] PROGMEM = {
  { 210, 210, 210, 210, 210, 365, 320, 240, 125 },  // напряжение одной ячейки аккумулятора
  { 245, 243, 241, 243, 235, 420, 365, 270, 160 },  // напряжение заряда ячейки аккумулятора
  { 271, 273, 250, 260, 240, 0, 0, 0, 0 },          // напряжение дозаряда ячейки аккумулятора - только для свинцово-кислотных
  { 185, 185, 185, 185, 185, 275, 280, 160, 100 },  // напряжение разряда ячейки аккумулятора
};

// ток заряда, указано в процентах от емкости Акб
//{ Pb Ca/Ca, Pb Ca+, Pb Sur, Pb AGM, Pb Gel, Li-ion, LiFePo4, LiTit, NiCd/Mh }
const uint8_t bt_cur[3][9] PROGMEM = {
  { 10, 10, 10, 10, 10, 50, 50, 100, 100 },  // ток заряда ячейки аккумулятора, указано в процентах от емкости Акб
  { 2, 2, 2, 2, 1, 0, 0, 0, 0 },             // ток дозаряда ячейки аккумулятора,...
  { 4, 4, 4, 4, 4, 50, 50, 50, 50 },         // ток разряда ячейки аккумулятора,...
};

class Batt {
public:
  uint16_t Volt(uint8_t i) {
    return (uint16_t)pgm_read_word(&bt_volt[i][pam.typeAkb]) * 10 * pam.Voltage;
  }
  int16_t Cur(uint8_t i) {
    return (int16_t)pgm_read_byte(&bt_cur[i][pam.typeAkb]) * 10 * pam.Capacity;
  }
} bat;

enum : uint8_t {
  volt_cell,             // 0 напряжение одной ячейки аккумулятора
  volt_cell_charge,      // 1 напряжение заряда ячейки аккумулятора
  volt_cell_add_charge,  // 2 напряжение дозаряда ячейки аккумулятора - только для свинцово-кислотных
  volt_cell_discharge,   // 3 напряжение разряда ячейки аккумулятора
};

enum : uint8_t {
  curr_cell_charge,     // 0 ток заряда ячейки аккумулятора, указано в процентах от емкости Акб
  curr_cell_addcharge,  // 1 ток дозаряда ячейки аккумулятора
  curr_cell_discharge,  // 2 ток разряда ячейки аккумулятора
};

void (*resetFunc)(void) = 0;  // функция reset с адресом 0

#include "INA226int.h"  // Класс INA226
#include "DCDC.h"       // класс управления DC-DC модулем
#include "Classes.h"    // классы

void delay_sec(uint8_t sec) {
  start_second_usr();  // старт счета секунд
  while (get_second_usr() <= sec) _NOP();
  stop_second_usr();
}

int main() {
// Настройка микроконтроллера
#if defined(__LGT8FX8P__)
  lgt8fx8x_clk_src();  // Настройка тактовой частоты LGT8
#ifdef LGT8_TIMER3
  timer3_init();
#endif
  uDSC_ON();  // Включить ускоритель вычислений uDSC
#endif

  mSerial.write('S');

  timer0_init();  // Настройка таймера 0 (CTC режим, генерирует прерывание каждые 1мс)

  mSerial.begin(SERIAL_SPEED);  // 9600   115200

  // настройка пинов
  gio::mode(PWMCH, OUTPUT);     // ШИМ заряд
  gio::mode(BUZER, OUTPUT);     // пин вывода звука
  gio::mode(BUFERPIN, OUTPUT);  // управление реле нагрузки в буферном режиме

#if (DISCHAR == 1)
  gio::mode(PWMDCH, OUTPUT);  // ШИМ разряд
#endif
#if (POWPIN)
  gio::mode(RELAY220, OUTPUT);  // управление реле подключения к сети 220В, или индикатор сети
#endif
#if (PROT)
  gio::mode(PROTECT, OUTPUT);  // управление защитой
  gio::low(PROTECT);           // открыть защитный транзистор
#endif
#if (GUARDA0)
  gio::mode(PROTECTBLOCK, OUTPUT);  // принудительная блокировка модуля защиты
#endif
#if (FAN)
  gio::mode(PWMKUL, OUTPUT);  // вентилятор
  // Пины D9 и D10 - 30 Гц для вентилятора
  TCCR1A = 0b00000001;  // 8bit
  TCCR1B = 0b00000101;  // x1024 phase correct
#endif

#if (EBSTEP != EB_STEP4_LOW)
  enc.setEncType(EBSTEP);  // установить тип энкодера (EB_STEP4_LOW, EB_STEP4_HIGH, EB_STEP2, EB_STEP1)
#endif
#if (POWPIN == 1)
  Relay_on(true);  // включить сеть 220В
#endif
  // частота I2C в герцах // влияет на INA226 и на дисплей
  Wire.begin(WIRE_CLOCK);
  lcd.init();       // Инициализация дисплея
  lcd.backlight();  // Подключение подсветки

// сброс настроек при первой прошивке МК
#if defined(__LGT8FX8P__)
  if (lgt_eeprom_read_byte(MEM_RESET) != MEMVER) Reset_settings(1);  // сброс настроек
#else
  if (EEPROM.read(MEM_RESET) != MEMVER) Reset_settings(1);  // сброс настроек
#endif

  for (uint8_t x = 0; x < 8; x++) lcd.createChar(x, &simb_array[x][0]);  // загрузка в память дисплея своих символов(состояние акб)

  // Приветствие. Версия прошивки и тип контроллера
  lcd.setCursor((uint8_t)((DISPLAYx - 7) / 2), (uint8_t)(DISPLAYy / 2 - 1));
  lcd.print(F(txt_ViktoRi));                                               // *      ViktoRi       *
  lcd.setCursor((uint8_t)((DISPLAYx - 12) / 2), (uint8_t)(DISPLAYy / 2));  // *   Ver 1.0-328p     *
  lcd.print(F(VER));

  start_second_usr();  // старт счета секунд
  Speaker(500);        // функция звукового сигнала (время в миллисекундах)
#if (FAN)
  gio::high(PWMKUL);  // запуск вентилятора, проверка работоспособности
#endif

#if (VOLTIN or SENSTEMP1 == 2 or SENSTEMP2 == 2)
  // настройка АЦП
  ADC_init(DIVIDER, ADC_VCC);                             // DIVIDER 64  // делитель частоты АЦП (2, 4, 8, 16, 32, 64, 128), Выбрать источник опорного напряжения АЦП (ADC_1V1, ADC_AREF, ADC_VCC)
  _vmax = (uint16_t)get_epprom_servise(POWERMAX) * 1000;  // Максимально допустимое напряжение от БП
#endif

  // задержка
  // Ожидание 3 секунды в течении которых удержанием кнопки Стоп или энкодера можно сбросить настройки по умолчанию
  while (get_second_usr() <= 3) {
    butt.Tick();
#if (VOLTIN == 1)
    // замер напряжения БП - чтобы АЦП вошел в норму
    adc_v.sample();  // считываем данные с АЦП с накоплением и усреднением
#endif
    if (butt.tick == STOPHELD or butt.tick == OKHELD) {
#if (FAN)
      gio::low(PWMKUL);  // остановка вентилятора
#endif
      Reset_settings(1);  // сброс настроек - 1 Стереть все.
    }
  }
  stop_second_usr();

  do {
    bool tr = true;
#if (SENSTEMP1 == 1)
    // датчик температуры DS18B20
    if (tr_Q1.online()) {
      tr_Q1.setResolution(9);  // Установить разрешение термометра 9-12 бит, разрешающей способность - 0,5 (1/2) °C, 0,25 (1/4) °C, 0,125 (1/8) °C и 0,0625 (1/16) °C
      tr_Q1.requestTemp();     // Запросить новое преобразование температуры
    } else tr = false;
#endif
#if (SENSTEMP2 == 1)
    // датчик температуры DS18B20
    if (tr_akb.online()) {
      tr_akb.setResolution(9);  // Установить разрешение термометра 9-12 бит, разрешающей способность - 0,5 (1/2) °C, 0,25 (1/4) °C, 0,125 (1/8) °C и 0,0625 (1/16) °C
      tr_akb.requestTemp();     // Запросить новое преобразование температуры
    } else tr = false;
#endif
    if (tr == false) {
      lcd.print(F(txt7));   // "DS18B20 "
      lcd.print(F(txt21));  // "error"
      delay_sec(2);
    }
  } while (0);

// чтение данных из EPPROM
#if defined(__LGT8FX8P__)
  lgt_eeprom_read_block(((uint8_t *)&vkr), MEM_VKR, sizeof(vkr));                                         // системные данные
  lgt_eeprom_read_block(((uint8_t *)&pam), (uint16_t)(sizeof(pam) * vkr.profil + MEM_PAM), sizeof(pam));  // данные профиля
#else
  EEPROM.get(MEM_VKR, vkr);                                    // системные данные
  EEPROM.get((int)(sizeof(pam) * vkr.profil + MEM_PAM), pam);  // данные профиля
#endif
  if (pam.Mode > POINTMODE) Reset_settings(1);  // сброс настроек
  
  // конфигурация INA226
  if (ina.begin()) ina.start();  // старт замеров INA
  else {
    lcd.clear();
    lcd.print(F(txt6));  // INA226 error
    delay_sec(2);
  }

#if (MCP4725DAC)
  if (!dac.testConnection()) {
    lcd.clear();
    lcd.print(F("MCP4725"));
    print_mode(ERROR);  // "error"
    delay_sec(2);
  }
#endif

#if (FAN)
  kul.begin();  // инициализация кулера
#endif

  // если заряд не был завершен корректно
  if (bitRead(pam.MyFlag, ACTIVITI)) {
    lcd.clear();
    print_mode(MODE);
    bitWrite(pam.MyFlag, ACTIVITI, (Choice(10, true)));
    lcd.clear();
  }
#if (TIME_LIGHT)
  disp.Light_setTime();  // установить время подсветки дисплея если оно больше 0
#endif

  mSerial.write('P');

  for (;;) {
    Menu1602();    // заряд отключен. Меню v4.0.
    Operations();  // заряд включен. Работа
  }
  return 0;
}
// Конец программы
