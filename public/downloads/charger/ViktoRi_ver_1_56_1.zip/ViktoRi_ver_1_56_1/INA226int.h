
#include <Arduino.h>
#include <microWire.h>

/* Public-определения (константы) */
#define INA226_VBUS true     // Канал АЦП, измеряющий напряжение шины (0-36в)
#define INA226_VSHUNT false  // Канал АЦП, измеряющий напряжение на шунте

// Время выборки (накопления сигнала для оцифровки)
#define INA226_CONV_140US 0b000
#define INA226_CONV_204US 0b001
#define INA226_CONV_332US 0b010
#define INA226_CONV_588US 0b011
#define INA226_CONV_1100US 0b100
#define INA226_CONV_2116US 0b101
#define INA226_CONV_4156US 0b110
#define INA226_CONV_8244US 0b111

// Встроенное усреднение (пропорционально увеличивает время оцифровки)
#define INA226_AVG_X1 0b000
#define INA226_AVG_X4 0b001
#define INA226_AVG_X16 0b010
#define INA226_AVG_X64 0b011
#define INA226_AVG_X128 0b100
#define INA226_AVG_X256 0b101
#define INA226_AVG_X512 0b110
#define INA226_AVG_X1024 0b111

/* Private-определения (адреса) */
#define INA226_CFG_REG_ADDR 0x00
#define INA226_SHUNT_REG_ADDR 0x01
#define INA226_VBUS_REG_ADDR 0x02
#define INA226_POWER_REG_ADDR 0x03
#define INA226_CUR_REG_ADDR 0x04
#define INA226_CAL_REG_ADDR 0x05

#define INA226_REG_MASKENABLE 0x06
#define INA226_REG_ALERTLIMIT 0x07

#define INA226_BIT_AFF 0x0010  // (бит 4)  // Чтение регистра срабатывания Alert

#define INA226_BIT_SOL (1 << 15)  //0x8000  // (бит 15)Shunt Voltage Over-Voltage. Установка в 1 этого бита конфигурирует установку ножки Alert, если измеренное напряжение шунта превысило значение, запрограммированное в Alert Limit Register.
//#define INA226_BIT_SUL        0x4000  // (бит 14)Shunt Voltage Under-Voltage. Установка в 1 этого бита конфигурирует установку ножки Alert, если измеренное напряжение шунта упало ниже значения, запрограммированного в Alert Limit Register.
//#define INA226_BIT_BOL        0x2000  // (бит 13) Bus Voltage Over-Voltage. Установка в 1 этого бита конфигурирует установку ножки Alert, если измеренное напряжение VBUS превысило значение, запрограммированное в Alert Limit Register.
//#define INA226_BIT_BUL        0x1000  // (бит 12)Bus Voltage Under-Voltage. Установка в 1 этого бита конфигурирует установку ножки Alert, если измеренное напряжение VBUS упало ниже значения, запрограммированного в Alert Limit Register.
//#define INA226_BIT_POL        0x0800  // (бит 11)Power Over-Limit. Установка в 1 этого бита конфигурирует установку ножки Alert, если вычисленная мощность после измерения напряжения VBUS превысило значение, запрограммированное в Alert Limit Register.
//#define INA226_BIT_CNVR       0x0400  // (бит 10)Conversion Ready. Установка в 1 этого бита конфигурирует установку ножки Alert, когда установится Conversion Ready Flag (бит 3), показывая тем самым готовность к следующему преобразованию.
//#define INA226_BIT_AFF        0x0010  // (бит 4)Alert Function Flag. Хотя в любой момент времени ножкой Alert может отслеживаться только одна функция Alert, ножкой Alert также может отслеживаться и флаг Conversion Ready. Чтение Alert Function Flag после события alert дает возможность пользователю определить, была ли источником этого события функция Alert.
//#define INA226_BIT_CVRF       0x0008  // (бит 3)Conversion Ready Flag, чтобы помочь координировать однократные преобразования (или triggered-преобразования). Бит Conversion Ready Flag установится после завершения всех преобразований, усреднений и умножений.
//#define INA226_BIT_OVF        0x0004  // (бит 2)Math Overflow Flag. Этот бит установится в 1, если арифметическая операция привела к ошибке переполнения. Это показывает, что данные тока и мощности могут быть недостоверными.
//#define INA226_BIT_APOL       0x0002  // (бит 1)Alert Polarity bit. Этот бит устанавливает полярность активации ножки Alert. 1 = инвертированная полярность (открытый коллектор с активной лог. 1). 0 = нормальная полярность (открытый коллектор с активным лог. 0, настройка по умолчанию).
//#define INA226_BIT_LEN        0x0001  // (бит 0)Alert Latch Enable - Конфигурирует разрешение защелкивания функции ножки Alert и бит Alert Flag. 1 = защелкивание разрешено (режим Latch). 0 = прозрачный режим (режим Transparent, настройка по умолчанию).



class INA226 {
public:
  // INA226(void){}

  // Инициализация и проверка
  bool begin(void) {
    _vs = _as = _vs_aver = _as_aver = 0;
    _se_aver = 10;

  //  Wire.begin();             // Инициализация шины I2c
    return testConnection();  // Вернуть true если все ок
  }

  // Установка встроенного усреднения выборок
  void setAveraging(uint8_t avg) {
    uint16_t cfg_register = readRegister(INA226_CFG_REG_ADDR) & ~(0b111 << 9);  // Читаем конф. регистр, сбросив биты AVG2-0
    writeRegister(INA226_CFG_REG_ADDR, cfg_register | avg << 9);                // Пишем новое значение конф. регистр
  }

  // Установка разрешения для выбранного канала
  void setSampleTime(bool ch, uint8_t mode) {
    uint16_t cfg_register = readRegister(INA226_CFG_REG_ADDR);  // Читаем конф. регистр
    cfg_register &= ~((0b111) << (ch ? 6 : 3));                 // Сбрасываем нужную пачку бит, в зависимости от канала
    cfg_register |= mode << (ch ? 6 : 3);                       // Пишем нужную пачку бит, в зависимости от канала
    writeRegister(INA226_CFG_REG_ADDR, cfg_register);           // Пишем новое значение конф. регистра
  }

  // Чтение напряжения, mV
  uint16_t getVoltage(void) {
    uint16_t value = readRegister(INA226_VBUS_REG_ADDR);  // Чтение регистра напряжения
    if (value == 0) return 0;
    if (vkr.inaKoof == 12500u) {
      // гораздо более скоростное (в 7 раз) умножение на 1,25 (_vkoof) с математическим округлением
      uint32_t j = value;
      j <<= 3;
      value = (uint16_t)((j + (j >> 2) + 5) >> 3);  // берем четвертую часть числа (j >> 2) и прибавляем к исходному числу, (плюс 5) - математическое округление.
    } else {
#if defined(__LGT8FX8P__)
      DSC_MUL(value, vkr.inaKoof);  // value * _vkoof
      DA_INC((uint16_t)5000);       // + 500
      DA_DIV_get((uint16_t)10000);  // / 10000
      value = DA_get_int();
#else
      value = (uint16_t)(((uint32_t)value * vkr.inaKoof + 5000u) / 10000u);  // LSB = 1.25mV = 0.00125V
#endif
    }
    return value;
  }

  // Чтение тока, mA
  int16_t getCurrent(void) {
    int16_t value = readRegister(INA226_CUR_REG_ADDR);  // Чтение регистра тока
    if (value < (int8_t)(3) and value > (int8_t)(-3)) return 0;
#if defined(__LGT8FX8P__)
    DSC_MUL((uint16_t)abs(value), (uint16_t)_current_lsb_int);  // value * _current_lsb_int
    DA_INC((uint16_t)2048);
    DA_shiftR(12);  // >> 12
    int16_t val = DA_get_intt();
    return ((value > 0) ? val : -val);
#else
    // LSB рассчитывается на основе макс. ожидаемого тока, умножаем и возвращаем  return value * _current_lsb;
    //  return (int16_t)(((val * _current_lsb_int + 2048u) >> 12); // 2048 округление
    uint32_t val = abs(value);
    val = (val * _current_lsb_int + 2048u) >> 12;
    return (int16_t)((value > 0) ? val : -val);
#endif
  }

  // возвращает милливатты
  int32_t getsPower(void) {
#if defined(__LGT8FX8P__)
    DSC_MUL(voltsec, abs(ampersec));  // voltsec * abs(ampersec)
    DA_INC(500);                      // + 500
    DA_DIV(1000);                     // / 1000
    return (int32_t)DA_get_long();
#else
    return ((int32_t)voltsec * abs(ampersec) + 500) / 1000;
#endif
  }

  // Чтение регистра срабатывания Alert
  bool isAlert(void) {
    return ((readRegister(INA226_REG_MASKENABLE) & INA226_BIT_AFF) == INA226_BIT_AFF);
  }

  //********* вычисление среднего ***********
  uint16_t voltms = 0;     // реальное значение
  int16_t amperms = 0;     // реальное значение
  uint16_t voltsec = 0;    // усредненное значение
  int16_t ampersec = 0;    // усредненное значение
  uint16_t volt_aver = 0;  // еще более усредненное значение
  int16_t curr_aver = 0;   // еще более усредненное значение

  /*
время выборки (накопления сигнала для оцифровки)
INA226_CONV_140US // 140 мкс
INA226_CONV_204US // 204 мкс
INA226_CONV_332US // 332 мкс
INA226_CONV_588US // 588 мкс
INA226_CONV_1100US // 1100 мкс
INA226_CONV_2116US // 2116 мкс
INA226_CONV_4156US // 4156 мкс
INA226_CONV_8244US // 8244 мкс
*/

  void start(void) {
    _current_lsb_int = (uint16_t)((250ul * 4096) / vkr.shunt);  // множитель для тока // 0,00025 в А // 0.25 в мА // (0.08192f / _shunt  - максимальный ток)
    //_power_lsb = _current_lsb * 25;                              // расчёт LSB для мощности (см. доку INA226)
    writeRegister(INA226_CFG_REG_ADDR, 0x8000);  // Принудительный сброс
    writeRegister(INA226_CAL_REG_ADDR, 2048);    // trunc(0.00512f / (_current_lsb * _shunt))  // Пишем значение в регистр калибровки
    // writeRegister(INA226_REG_MASKENABLE, INA226_BIT_SOL);  // сигнал Alert сработает при превышении напряжения на шунте 0,081 Вольт. При шунте 0,01 Ом ток срабатывания 0,08192/0,01=8,1А
    // writeRegister(INA226_REG_ALERTLIMIT, 32400);           // Alert - ограничение по максимальному току   // 0,081/0,0000025f   ограничение по напряжению на шунте 32400 * 0.0025 = 81мВ

    setSampleTime(INA226_VBUS, INA226_CONV_588US);     // время выборки напряжения // 588 + 332 = 920  // 140 + 140 = 280  280 * 4 = 1120
    setSampleTime(INA226_VSHUNT, INA226_CONV_1100US);  // время выборки тока
    //setAveraging(INA226_AVG_X4);                      // усреднение, по умолчанию усреднения нет(1, 4, 16, 64, 128, 256, 512, 1024).
  }

  int32_t average(int32_t aver, int32_t val) {
    return (((val << 6) - aver) >> 6);  // скользящее среднее - сгладить в 64 раз
  }

  bool sample(void) {
    bool fg = false;

    if (ina_flag) {
      ina_flag = false;
      fg = true;
      amperms = getCurrent();  // чтение тока -32767mA - +32767mA max
#if defined(__LGT8FX8P__)
      DSC_MUL(amperms, vkr.Ohms);  // amperms * vkr.Ohms
      voltms = DSC_SUB_get((uint16_t)getVoltage(), (int16_t)DA_DIV_get(1000));
#else
      voltms = getVoltage() - (int16_t)((int32_t)amperms * vkr.Ohms / 1000);  // vkr.Ohms / 1000 // чтение напряжения 0 - 65535mV max с корректировкой
#endif

      _vs += average(_vs, voltms);
      _as += average(_as, amperms);

      if (--_se_aver == 0) {
        _se_aver = 10;
        // Оптимизированное усреднение - избегаем операций с плавающей точкой. Используем коэффициент 1/50 как умножение на 51 и деление на 2^12 (4096)
        int32_t diff = _vs - _vs_aver;
        _vs_aver += (diff >> 5);  // diff*0.03125
        diff = _as - _as_aver;
        _as_aver += (diff >> 5);  // diff*0.03125
      }
    }
    return fg;
  }

  // преобразование промежуточных средних значений тока и напряжения в реальные значения
  void calc(void) {
    voltsec = (uint16_t)(_vs >> 6);
    ampersec = (int16_t)(_as >> 6);

    volt_aver = (uint16_t)((uint32_t)(_vs_aver + 32) >> 6);  // 32 - это значение для математического округления
    curr_aver = (int16_t)((int32_t)(_as_aver + 32) >> 6);
  }

private:
  const uint8_t _iic_address = 0x40;  // Адрес на шине I2c
  volatile int16_t _current_lsb_int;  // LSB для тока

  /********* вычисление среднего **********/
  int32_t _vs : 24;
  int32_t _as : 24;
  int32_t _as_aver;
  int32_t _vs_aver;
  uint8_t _se_aver;

  // Запись 16-ти битного регистра INA226
  void writeRegister(uint8_t address, uint16_t data) {
    Wire.beginTransmission(_iic_address);  // Начинаем передачу
    Wire.write(address);                   // Отправляем адрес
    Wire.write(highByte(data));            // Отправляем старший байт
    Wire.write(lowByte(data));             // Отправляем младший байт
    Wire.endTransmission();                // Заканчиваем передачу
  }

  // Чтение 16-ти битного регистра INA226
  uint16_t readRegister(uint8_t address) {
    Wire.beginTransmission(_iic_address);        // Начинаем передачу
    Wire.write(address);                         // Отправляем адрес
    Wire.endTransmission();                      // Заканчиваем передачу
    Wire.requestFrom(_iic_address, (uint8_t)2);  // Запрашиваем 2 байта
    return Wire.read() << 8 | Wire.read();       // Клеим и возвращаем результат
  }

  // Проверка присутствия
  bool testConnection(void) {
    Wire.beginTransmission(_iic_address);  // Начинаем передачу
    return (bool)!Wire.endTransmission();  // Сразу заканчиваем, инвертируем результат
  }
};
extern INA226 ina;  // адрес INA226
INA226 ina = INA226();
