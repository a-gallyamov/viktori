// вывод пунктов настроек
void Settings_point(uint8_t point, bool edit, int16_t x) {

  bool st = true;
  // изменение настроек
  if (pam.typeAkb > 4) {
    switch (point) {
      case 7:   // напряжение дозаряда
      case 8:   // ток дозаряда
      case 9:   // минимальный ток дозаряда
      case 10:  // время дозаряда, часы
      case 19:  // режим качели
        st = false;
        break;
    }
  }

  if (!edit) {
    // отображение настроек
    if (st) {
      switch (point) {
        case 0:
          PrintVA(pam.Volt_charge);  // напряжение заряда
          break;
        case 1:
          PrintVA(0, pam.Current_charge, 0, 0, 2);  // ток заряда
          break;
        case 2:
          PrintVA(pam.Volt_decrCur);  //     Напряжение при котором начинает снижаться ток
          break;
        case 3:
          PrintVA(0, pam.Current_charge_min, 0, 0, 2);  // минимальный ток заряда
          break;
        case 4:
          lcd.print(pam.Time_charge_h);  // время заряда
          lcd.write('h');
          break;
        case 5:
          lcd.print(pam.period_charge);  // Период заряда
          lcd.write('s');
          break;
        case 6:
          lcd.print(pam.period_discharge);  // Период разряда
          lcd.write('s');
          break;
        case 7:
          PrintVA(pam.Volt_add_charge);  // напряжение дозаряда
          break;
        case 8:
          PrintVA(0, pam.Current_add_charge, 0, 0, 2);  // ток дозаряда
          break;
        case 9:
          PrintVA(0, pam.Current_add_charge_min, 0, 0, 2);  // минимальный ток дозаряда
          break;
        case 10:
          lcd.print(pam.Time_add_charge_h);  // время дозаряда
          lcd.write('h');
          break;
        case 11:
          PrintVA(pam.Volt_discharge);  // напряжение разряда
          break;
        case 12:
          PrintVA(0, pam.Current_discharge, 0, 0, 2);  // ток разряда
          break;
        case 13:
          PrintVA(0, pam.Current_discharge_min, 0, 0, 2);  // ток завершения разряда
          break;
        case 14:
          PrintVA(pam.Volt_buffer);  // напряжение буферный режим
          break;
        case 15:
          PrintVA(pam.Volt_storage);  // напряжение режима хранения
          break;
        case 16:  // Предзаряд
          PrintOnOff(bitRead(pam.MyFlag, PRECHAR));
          break;
        case 17:
          PrintVA(pam.Volt_pre_charge);  // напряжение предзаряда
          break;
        case 18:
          PrintVA(0, pam.Current_pre_charge, 0, 0, 2);  // ток предзаряда
          break;
        case 19:
          PrintOnOff(bitRead(pam.MyFlag, OSCIL));  // режим качели
          break;
        case 20:
          lcd.print(pam.Round);  // колицество циклов
          break;
      }
    }
  } else {
    // изменение настроек
    if (st) {
      switch (point) {
        case 0:
          // напряжение заряда
          pam.Volt_charge = volt_step(pam.Volt_charge, x);
          PrintVA(pam.Volt_charge);
          break;
        case 1:
          // ток заряда
          pam.Current_charge = constrain_my(pam.Current_charge, CUR_CHARGE_MIN, CURRMAXINT - 500, x * STEP_CURR);
          PrintVA(0, pam.Current_charge, 0, 0, 2);
          ChargeTimeCalc();  // расчет времени заряда
          break;
        case 2:
          //  Напряжение при котором начинает снижаться ток
          pam.Volt_decrCur = constrain_my(pam.Volt_decrCur, STEP_VOLT * 10, pam.Volt_charge, x * STEP_VOLT);
          PrintVA(pam.Volt_decrCur);
          break;
        case 3:
          // минимальный ток заряда
          pam.Current_charge_min = constrain_my(pam.Current_charge_min, CURMIN, pam.Current_charge, x * 10);
          PrintVA(0, pam.Current_charge_min, 0, 0, 2);
          break;
        case 4:
          // время заряда
          pam.Time_charge_h = constrain_my(pam.Time_charge_h, 1, 255, x);
          lcd.print(pam.Time_charge_h);
          break;
        case 5:
          // Период заряда
          pam.period_charge = constrain_my(pam.period_charge, 1, 65535, x);
          lcd.print(pam.period_charge);
          break;
        case 6:
          // Период разряда
          pam.period_discharge = constrain_my(pam.period_discharge, 1, 65535, x);
          lcd.print(pam.period_discharge);
          break;
        case 7:
          // напряжение дозаряда
          pam.Volt_add_charge = volt_step(pam.Volt_add_charge, x);
          PrintVA(pam.Volt_add_charge);
          break;
        case 8:
          // ток дозаряда
          pam.Current_add_charge = constrain_my(pam.Current_add_charge, CUR_CHARGE_MIN, CURRMAXINT - 500, x * STEP_CURR_ADD);
          PrintVA(0, pam.Current_add_charge, 0, 0, 2);
          break;
        case 9:
          // минимальный ток дозаряда
          pam.Current_add_charge_min = constrain_my(pam.Current_add_charge_min, CUR_CHARGE_MIN, pam.Current_add_charge, x * 10);
          PrintVA(0, pam.Current_add_charge_min, 0, 0, 2);
          break;
        case 10:
          // время дозаряда, часы
          pam.Time_add_charge_h = constrain_my(pam.Time_add_charge_h, 1, 252, x);
          lcd.print(pam.Time_add_charge_h);
          break;
        case 11:
          // напряжение разряда
          pam.Volt_discharge = volt_step(pam.Volt_discharge, x);
          PrintVA(pam.Volt_discharge);
          break;
        case 12:
          // ток разряда
          pam.Current_discharge = constrain_my(pam.Current_discharge, STEP_CURR, CURRMAXINT - 500, x * STEP_CURR);
          PrintVA(0, pam.Current_discharge, 0, 0, 2);
          pam.Current_discharge_min = pam.Current_discharge;  // ток завершения разряда
          break;
        case 13:
          // ток завершения разряда
          pam.Current_discharge_min = constrain_my(pam.Current_discharge_min, 20, pam.Current_discharge, x * 10);
          PrintVA(0, pam.Current_discharge_min, 0, 0, 2);
          break;
        case 14:
          // напряжение буферного режима
          pam.Volt_buffer = volt_step(pam.Volt_buffer, x);
          PrintVA(pam.Volt_buffer);
          break;
        case 15:
          // напряжение режима Хранение
          pam.Volt_storage = volt_step(pam.Volt_storage, x);
          PrintVA(pam.Volt_storage);
          break;
        case 16:
          // Предзаряд
          if (x) InvBit(pam.MyFlag, PRECHAR);
          PrintOnOff(bitRead(pam.MyFlag, PRECHAR));
          break;
        case 17:
          // напряжение предзаряда
          pam.Volt_pre_charge = volt_step(pam.Volt_pre_charge, x);
          PrintVA(pam.Volt_pre_charge);
          break;
        case 18:
          // ток предзаряда
          pam.Current_pre_charge = constrain_my(pam.Current_pre_charge, CUR_CHARGE_MIN, pam.Current_charge, x * 10);
          PrintVA(0, pam.Current_pre_charge, 0, 0, 2);
          break;
        case 19:
          // режим качели
          if (x) InvBit(pam.MyFlag, OSCIL);  // инвертировать бит
          PrintOnOff(bitRead(pam.MyFlag, OSCIL));
          break;
        case 20:
          // цикл
          pam.Round = constrain_my(pam.Round, 1, 5, x);
          lcd.print(pam.Round);
          break;
#if (SERVICE == 1)
        case 21:
          // системные пaраметры на 3 нажатия
#if (ENCBUTT == 0)  // 0 - только энкодер
          if (enc.clicks == 3) {
            enc.clicks = 0;
#elif (ENCBUTT == 1)  // 1 - только кнопки
          if (OK.clicks == 3) {
            OK.clicks = 0;
#else                 // иначе - энкодер + OK + Stop или все
          if (enc.clicks == 3 or OK.clicks == 3) {
            enc.clicks = 0;
            OK.clicks = 0;
#endif
            serviceparam();  // изменение системныx параметров
            lcd.clear();
          }
#endif
          break;
        case 22:
          // сброс всех настроек
          Reset_settings(0);  // сброс настроек по умолчанию
          lcd.clear();
          break;
      }
    }
    ClearStr(10);  // очистить поле
  }
}

// печать статистики
void Prstatistic(int i, uint32_t time_i, int32_t Ah, int32_t Wh) {
  disp.printFromPGM(i);
#if (DISPLAYx == 16)
  Print_time(time_i, DISPLAYx - 5, 0);
#else
  Print_time(time_i, DISPLAYx - 8, 0);
#endif
  setCursory();
  PrintVA(0, 0, Ah, Wh);
}

// вывод статистики
void Statistics_point(uint8_t point) {
  switch (point) {
    case 0:
      // Заряд
      // *Zaryad     24:42*
      // *55.36Ah 366.35Wh*
      Prstatistic((int)(&modeTxt[CHARGE]), pam.Time_charge, pam.Ah_charge, pam.Wh_charge);
      break;
    case 1:
      //  Дозаряд
      // *Add charge 24:42*
      // *55.36Ah 366.35Wh*
      Prstatistic((int)(&modeTxt[ADDCHARGE]), pam.Time_addcharge, pam.Ah_addcharge, pam.Wh_addcharge);
      break;
    case 2:
      // Разряд
      // *Razryad    24:42*
      // *55.36Ah 366.35Wh*
      Prstatistic((int)(&modeTxt[DISCHARGE]), pam.Time_discharge, pam.Ah_discharge, pam.Wh_discharge);
      break;
    case 3:
      // Внутреннее сопротивление
      // *Resist       *
      // *20.3mOm 520A *
      disp.printFromPGM((int)(&menuTxt[6]));  // *Resist       *
      setCursory();
      lcd.print(((float)pam.Resist_1 / 100), 1);
      lcd.print(F("mOm "));
      lcd.print(pam.Resist_2);  // вывод пускового тока - напряжение делить на сопротивление
      lcd.write('A');
      break;
    default:
      // вывод значений емкости КТЦ
      {
        int32_t KTC[4] = { 0 };  //  Ah_discharge, Wh_discharge, Ah_charge, Wh_charge,
        uint16_t m = pam.Round;  // считать количество циклов в переменную
        m -= (point - 4);
#if defined(__LGT8FX8P__)
        lgt_eeprom_read_block(((uint8_t *)&KTC), ((m << 4) - 16 + MEM_KTC), sizeof(KTC));  // считать из памяти значения разряда, заряда roundi-цикла КТЦ
#else
        EEPROM.get(((m << 4) - 16 + MEM_KTC), KTC);  // считать из памяти значения разряда, заряда m-цикла КТЦ
#endif
        lcd.print(point - 3);         // 1
        lcd.print(F("D:"));           // 1D:
        PrintVA(0, 0, KTC[0], 0, 1);  // 1D:65.3Ah
        PrintVA(0, 0, 0, KTC[1], 0);  // 1D:65.3Ah 255Wh
        setCursory();
        lcd.print(point - 3);         // 1
        lcd.print(F("C:"));           // 1C:
        PrintVA(0, 0, KTC[2], 0, 1);  // 1C:65.3Ah
        PrintVA(0, 0, 0, KTC[3], 0);  // 1C:65.3Ah 255Wh
        break;
      }
  }
}

/*
*                *
------------------
*1D:65.3Ah 255Wh *
*1C:66.4AH 257Wh *
------------------
*/
