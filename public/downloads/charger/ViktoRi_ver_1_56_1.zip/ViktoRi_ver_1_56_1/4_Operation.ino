void Operations() {
  const uint8_t mode = pam.Mode;  // сохранить режим работы
  uint8_t roundi;
#if defined(__LGT8FX8P__)
  roundi = lgt_eeprom_read_byte(MEM_ROUNDi);  // считать из памяти
#else
  roundi = EEPROM.read(MEM_ROUNDi);  // считать из памяти
#endif
  // если флаг заряда установлен true то выполнять работу
  while (bitRead(pam.MyFlag, ACTIVITI)) {
    lcd.clear();
    print_mode(MODE);  //вывод режима
    setCursory();
    Saved();  // сохранить настройки
    Speaker(1000);
    // Выбор режима заряда
    switch (pam.Mode) {
      case CHARGE:
        // Заряд
        ChargeAkb(pam.Volt_charge, pam.Current_charge, pam.Current_charge_min, (uint32_t)pam.Time_charge_h, false);  // заряд, дозаряд откл
        if (bitRead(pam.MyFlag, ACTIVITI) and (--roundi == 0)) pam.Mode = STORAGE;                                   // если счетчик циклов равен 0 то завершить заряд // иначе повторить заряд
        break;
      case CHARGE_ADDCHARGE:
        // Заряд - Дозаряд
        switch (pam.Number) {
          case 1:
            // Заряд
            ChargeAkb(pam.Volt_charge, pam.Current_charge, pam.Current_charge_min, (uint32_t)pam.Time_charge_h, false);  // заряд дозаряд откл
            pam.Number++;
            break;
          case 2:
            // Дозаряд
            // дать отстояться
            Wait(5);  // Функция ожидания - минут

            ChargeAkb(pam.Volt_add_charge, pam.Current_add_charge, pam.Current_add_charge_min, (uint32_t)pam.Time_add_charge_h, true);  // Включить дозаряд
            if (bitRead(pam.MyFlag, ACTIVITI)) {
              if (--roundi == 0) pam.Mode = STORAGE;  // если счетчик циклов равен 0 то завершить заряд
              else pam.Number = 1;                    // иначе повторить заряд - дозаряд
            }
            break;
        }
        break;
      case ASYMMETRIC:                                                                                               // 2 ассиметричный заряд
        ChargeAkb(pam.Volt_charge, pam.Current_charge, pam.Current_charge_min, (uint32_t)pam.Time_charge_h, false);  // заряд, дозаряд откл
        if (bitRead(pam.MyFlag, ACTIVITI) and (--roundi == 0)) pam.Mode = STORAGE;                                   // если счетчик циклов равен 0 то завершить заряд // иначе повторить заряд
        break;
      case BRANIMIR:
        // Заряд по Бранимиру
#if (BRRANIMIR == 1)
        switch (pam.Number) {
          case 1:
            roundi--;
            // Бранимир Заряд 20 часов после достижения максимального напряжения
            ChargeAkb(pam.Volt_charge, (int16_t)pam.Capacity * 10, constrain((int16_t)pam.Capacity + (pam.Capacity >> 1), CURMIN, 120), 48, false);  // заряд (Напр. заряда, ток заряда, ток завершения заряда, время заряда, дозар. откл.

            if (bitRead(pam.MyFlag, BRANIM) or roundi == 0) pam.Number = 3;  // если ток заряда снизился до установленного то переходим в дозаряд
            else if (bitRead(pam.MyFlag, BRANIMBOIL)) pam.Number++;          // иначе если время заряда превысило 20 часов  - перемешивание
            break;
          case 2:
            bitClear(pam.MyFlag, BRANIMBOIL);
            // Бранимир перемешивание
            ChargeAkb(pam.Volt_add_charge, (int16_t)pam.Capacity * 20, constrain(((int16_t)pam.Capacity << 3), CURMIN, 1500), 1, false);  // перемешивание (Напр. заряда, ток заряда, ток окончания заряда, время заряда, дозар. откл.
            pam.Number = 1;                                                                                                               // снова заряд малым током
            break;
          case 3:
            // Бранимир дозаряд
            // дать отстояться
            Wait(5);  // Функция ожидания - минут

            if (pam.typeAkb < LI_ION) ChargeAkb(pam.Volt_add_charge, constrain(bat.Cur(curr_cell_addcharge), CUR_CHARGE_MIN, CURRMAXINT - 500), pam.Current_add_charge / 3, 10, true);  // дозаряд (Напр. заряда, ток заряда, ток окончания заряда, время заряда, дозар. вкл.
            pam.Mode = STORAGE;
            break;
        }
#else
        bitClear(pam.MyFlag, ACTIVITI);
#endif
        break;
      case ADDCHARGE:
        // Дозаряд
        ChargeAkb(pam.Volt_add_charge, pam.Current_add_charge, pam.Current_add_charge_min, (uint32_t)pam.Time_add_charge_h, true);  // Включить дозаряд
        if (bitRead(pam.MyFlag, ACTIVITI) and (--roundi == 0)) pam.Mode = STORAGE;                                                  // если счетчик циклов равен 0 то завершить дозаряд
        break;
      case DISCHARGE:
        // Разряд
#if (DISCHAR == 1)
        Discharge();                                                                            //разряд аккумулятора
        if (bitRead(pam.MyFlag, ACTIVITI) and (--roundi == 0)) bitClear(pam.MyFlag, ACTIVITI);  // если счетчик циклов равен 0 то завершить разряд// иначе повторить разряд
#else
        bitClear(pam.MyFlag, ACTIVITI);
#endif
        break;
      case KTCycle:
        //  Котнтрольно-тренировочный цикл
#if (DISCHAR == 1)
        {
          int32_t KTC[4];  //  Ah_discharge, Wh_discharge, Ah_charge, Wh_charge,
#if defined(__LGT8FX8P__)
          lgt_eeprom_read_block(((uint8_t *)&KTC), (((uint16_t)roundi << 4) - 16 + MEM_KTC), sizeof(KTC));  // считать из памяти значения разряда, заряда roundi-цикла КТЦ
                                                                                                            // lgt_eeprom_readSWM((((uint16_t)roundi << 4) - 16 + MEM_KTC), ((uint32_t *)&KTC), (sizeof(KTC) / sizeof(uint32_t)));  // считать 32-битные данные из EEPROM
#else
          EEPROM.get((((uint16_t)roundi << 4) - 16 + MEM_KTC), KTC);  // считать из памяти значения разряда, заряда roundi-цикла КТЦ
#endif
          switch (pam.Number) {
            case 1:
              // предварительный заряд
              ChargeAkb(pam.Volt_charge, pam.Current_charge, pam.Current_charge_min, (uint32_t)pam.Time_charge_h, false);  // заряд, дозаряд откл
              pam.Number++;
              Res_mem_char();  // сброс значений заряда
              break;
            case 2:
              // дать отстояться
              Wait((uint16_t)pam.Capacity << 1);  // Функция ожидания - минут
              pam.Number++;
              break;
            case 3:
              // Разряд
              // Res_mem_dischar();  // сброс значений разряда
              Discharge();  //разряд аккумулятора
              pam.Number++;
              KTC[0] = pam.Ah_discharge;  //  Ah_discharge, Wh_discharge, Ah_charge, Wh_charge,
              KTC[1] = pam.Wh_discharge;
#if defined(__LGT8FX8P__)
              lgt_eeprom_update_block(((uint8_t *)&KTC), (((uint16_t)roundi << 4) - 16 + MEM_KTC), sizeof(KTC));
              // lgt_eeprom_writeSWM((((uint16_t)roundi << 4) - 16 + MEM_KTC), ((uint32_t *)&KTC), (sizeof(KTC) / sizeof(uint32_t)));  // записать 32-битные данные в EEPROM);
#else
              EEPROM.put((((uint16_t)roundi << 4) - 16 + MEM_KTC), KTC);  // сохранить в памяти значения разряда roundi-цикла КТЦ
#endif

              break;
            case 4:
              // заряд
              // Res_mem_char();     // сброс значений заряда
              ChargeAkb(pam.Volt_charge, pam.Current_charge, pam.Current_charge_min, (uint32_t)pam.Time_charge_h, false);  // заряд, дозаряд откл
              KTC[2] = pam.Ah_charge;                                                                                      //  Ah_discharge, Wh_discharge, Ah_charge, Wh_charge,
              KTC[3] = pam.Wh_charge;
#if defined(__LGT8FX8P__)
              lgt_eeprom_update_block(((uint8_t *)&KTC), (((uint16_t)roundi << 4) - 16 + MEM_KTC), sizeof(KTC));
              // lgt_eeprom_writeSWM((((uint16_t)roundi << 4) - 16 + MEM_KTC), ((uint32_t *)&KTC), (sizeof(KTC) / sizeof(uint32_t)));  // записать 32-битные данные в EEPROM);
#else
              EEPROM.put((((uint16_t)roundi << 4) - 16 + MEM_KTC), KTC);  // сохранить в памяти значения разряда roundi-цикла КТЦ
#endif
              if (bitRead(pam.MyFlag, ACTIVITI)) {
                if (--roundi == 0) pam.Number++;  // если счетчик циклов равен 0 то перейти в Дозаряд
                else {
                  // иначе повторить КТЦ
                  pam.Number = 2;
                  Res_mem_dischar();  // сброс значений разряда
                  Res_mem_char();     // сброс значений заряда
                }
              }
              break;
            case 5:
              // Дозаряд
              // дать отстояться
              Wait(5);  // Функция ожидания - минут

              if (pam.typeAkb < 5) ChargeAkb(pam.Volt_add_charge, pam.Current_add_charge, pam.Current_add_charge_min, (uint32_t)pam.Time_add_charge_h, true);  // Включить дозаряд
              pam.Mode = STORAGE;                                                                                                                              // перейти в Хранение
              break;
          }
        }
#else
        bitClear(pam.MyFlag, ACTIVITI);
#endif
        break;
      case STORAGE:  // хранение
      case BUFER:    // буферный режим
        roundi = 1;
        Storage();
        pam.Mode = mode;
        bitClear(pam.MyFlag, ACTIVITI);
        break;
    }  // выбор режима
    second_flag_usr = false;  // счет времени заряда откл.
#if defined(__LGT8FX8P__)
    lgt_eeprom_update_byte(MEM_ROUNDi, roundi);
#else
    EEPROM.update(MEM_ROUNDi, roundi);  // сохранить количество циклов
#endif

    if (BitIsClear(pam.MyFlag, ACTIVITI)) {
      Saved();  // сохранить настройки
      End();    // Завершение работы
    }
  }
  // цикл работы
}
