#include <Arduino.h>
//#include "1_User_Setup.h"

struct Tyme {
  uint32_t local;    // сюда сохраняем время заряда из памяти в сек (при запуске заряда) 
  uint32_t real_tm;  // сюда рассчитывается полное время заряда (каждую секунду)

  void cal_real_tm(void) {
    real_tm = local + get_second_usr();  // рассчитать количество всех секунд заряда (каждую секунду)
  }
};


// класс управления дисплеем
class Display {
public:
  // Display(void) {}

  // Функции управления подсветкой
#if (TIME_LIGHT)
  void Light_setTime(void) {
    _light_tm = (uint32_t)get_epprom_servise(TIMELIGHT) * 60000;  // установить время подсветки
  }

  void Light_high(void) {
    lcd.setBacklight(true);  // включение подсветки
    _light_time = millis_my();  // старт отсчета времени подсветки
  }

  void Light_low(void) {
    if (get_epprom_servise(TIMELIGHT) and (millis_my() - _light_time > _light_tm)) {
      _light_time = millis_my();
      lcd.setBacklight(false);  // если разрешено отключение подсветки и время вышло отключение подсветки
    }
  }

  // функция отключает подсветку если отключилось питание от акб
void Light_power(void) {
  if (BitIsClear(flag_global, POWERON)) Light_low();
}
#endif

  // функция для печати из PROGMEM
  void printFromPGM(int charMap) {
    uint16_t ptr = pgm_read_word(charMap);  // получаем адрес из таблицы ссылок
    while (true) {
      char c = pgm_read_byte(ptr++);
      if (c == '\0') break;
      lcd.write(c);  // выводим в монитор или куда нам надо // всю строку до нулевого символа
    }
  }

private:
  // список членов для использования внутри класса

#if (TIME_LIGHT)
  uint32_t _light_time;
  uint32_t _light_tm;
#endif
};
extern Display disp;
Display disp = Display();

// работа с АЦП ...
#if (VOLTIN or SENSTEMP1 == 2 or SENSTEMP2 == 2)
#include <ADCaverage.h>

#if (VOLTIN)
// замер напряжения БП
VoltRead adc_v(POWIN, DIV_R1, DIV_R2);

#ifdef VKORRECT
#if defined(__LGT8FX8P__)
// корректировка напряжения БП
inline void volt_korrect(void) {
  if (vkr.Vref != 1000) {
    DSC_MUL(adc_v.volt, vkr.Vref);  // умножить
    DA_DIV(1000);                   // разделить на 1000
    adc_v.volt = DA_get_int();
  }
}
#else
// корректировка напряжения БП
inline void volt_korrect(void) {
  if (vkr.Vref != 1000) adc_v.volt = (uint16_t)((uint32_t)adc_v.volt * vkr.Vref / 1000);
}
#endif

#endif

uint16_t _vmax;  // максимальное напряжение от БП

void VoltINcheck(void) {
  static uint8_t _timer = 0;
  static uint8_t _k = 0;
  // проверить напряжение БП на наличие и на превышение (с периодом в 255 мс)
  if (++_timer == 0) {
    adc_v.compute();  // рассчитать среднее напряжение БП  20 мкс
#ifdef VKORRECT
    volt_korrect();  // корректировка напряжения БП
#endif
    bitWrite(flag_global, POWERON, (adc_v.volt > ina.voltsec + 1000));  // если есть питание от БП (если напряжение от БП превышает напряжение на АКБ)

    if (adc_v.volt > _vmax) {
      // если напряжение превысит максимальное проводим 5 проверок
      if (++_k > 6) {
        _k = 0;
        bitClear(flag_global, POWERHIGH);  // Напряжение от БП превышено
        dcdc.Off();                        // отключить заряд, разряд.
      }
    } else {
      _k = 0;
      bitSet(flag_global, POWERHIGH);  // Напряжение от БП в норме
    }

#if (POWPIN == 2)
    gio::write(RELAY220, bitRead(flag_global, POWERON));  // индикатор включения БП в сеть
#endif
  }
}
#endif

#if (SENSTEMP1 == 2)
// датчик температуры NTC транзистора
NTCRead ntc_q(PINTERM1, NTCR1, NTCRS2, NTCB1, TEMPBASE1);
#endif

#if (SENSTEMP2 == 2)
// датчик температуры NTC аккумулятора
NTCRead ntc_akb(PINTERM2, NTCR2, NTCRS2, NTCB2, TEMPBASE2);
#endif
#endif
/*
#if (SENSTEMP1 == 1 or SENSTEMP2 == 1)
#include <GyverDS18.h>  // Библиотека датчика температуры DS18B20.
#if (SENSTEMP1 == 1)
GyverDS18Single tr_Q1(PIN_Q1_DS18, false);  // датчик температуры силового транзистора.
#endif
#if (SENSTEMP2 == 1)
GyverDS18Single tr_akb(PIN_AKB_DS18, false);  // датчик температуры аккумулятора.
#endif
#endif
*/
#if (SENSTEMP1 == 1 or SENSTEMP2 == 1)
#include <microDS18B20.h>  // Библиотека датчика температуры DS18B20.
#if (SENSTEMP1 == 1)
  // датчик температуры силового транзистора.
MicroDS18B20<PIN_Q1_DS18> tr_Q1;
#endif
#if (SENSTEMP2 == 1)
// датчик температуры аккумулятора.
MicroDS18B20<PIN_AKB_DS18> tr_akb;
#endif
#endif

#if (SENSTEMP1 > 0)
int8_t temp_Q1 = 0;
// чтение температуры транзистора, вызывать раз в секунду
inline void temp_Q1_read(void) {
#if (SENSTEMP1 == 1)
  if (tr_Q1.readTemp()) temp_Q1 = tr_Q1.getTempInt();  //  прочитать температуру с датчика. [true если успешно]  // получить значение температуры в int
  tr_Q1.requestTemp();                                 // Запросить новое преобразование температуры
#endif

#if (SENSTEMP1 == 2)
  ntc_q.compute();  // рассчитать температуру термистора 300 мкс
  temp_Q1 = ntc_q.temp;
#endif

// если подключен датчик температуры и разрешено уменьшать ток при превышении температуры транзистора
#if (SENSTEMP1 and GUARDTEMP)
  // если превышена температура
  if (temp_Q1 > get_epprom_servise(DEGCUR)) bitSet(flag_global, TR_Q1_ERR);                                                 // превышена температура Q1
  else if (bitRead(flag_global, TR_Q1_ERR) and temp_Q1 < get_epprom_servise(DEGCUR) - 5) bitClear(flag_global, TR_Q1_ERR);  // температура Q1 снизилась на 5 гр.
#endif
}
#endif

#if (SENSTEMP2 > 0)
int8_t temp_akb = 0;
bool temp_akb_status = true;
// чтение температуры акб, вызывать раз в секунду
inline void temp_akb_read(void) {
#if (SENSTEMP2 == 1)
  if (tr_akb.readTemp()) temp_akb = tr_akb.getTempInt();  //  прочитать температуру с датчика. [true если успешно]  // получить значение температуры в int
  tr_akb.requestTemp();                                   // Запросить новое преобразование температуры
  if (temp_akb == 0) temp_akb_status = false; // (int8_t)(-66) - значение при отключенном датчике
  else temp_akb_status = true;
#endif

#if (SENSTEMP2 == 2)
  ntc_akb.compute();  // рассчитать температуру термистора 300 мкс
  temp_akb = ntc_akb.temp;
  if (temp_akb < (int8_t)(-30)) temp_akb_status = false; // (int8_t)(-66) - значение при отключенном датчике
  else temp_akb_status = true;
#endif

// контролировать наличие датчика температуры
// 
}
#endif

#if (FAN)
#if (SENSTEMP1 == 0)
int8_t temp_Q1 = 0;
#endif

// класс управления кулером
class KULER {
public:
  // KULER(void) {}

  // инициализация
  void begin(void) {
    _kul = 0;  // значение ШИМ кулера
    for (uint8_t i = CURFANON; i <= CURFANMAX; i++) _curfan[i - CURFANON] = (int16_t)get_epprom_servise(i) * 100;
  }

#if (KULDISCHAR)
  bool onse = false;
  void ONonse(bool x) {
    onse = x;
    digitalWrite_speed(PWMKUL, x);
  }
#endif

  inline void fan(void) {
#if (KULDISCHAR)
    if (onse) return;
#endif
    int16_t amp = abs(ina.ampersec);  // чтение тока
    switch (get_epprom_servise(FANMODE)) {
      case 1:
        // управление кулером ШИМ
        if (temp_Q1 >= get_epprom_servise(DEGMAX)) _kul = 255;
        else _kul = temp_Q1 ? ((temp_Q1 >= get_epprom_servise(DEGON)) ? (_kul ? map_my(temp_Q1, get_epprom_servise(DEGOFF), get_epprom_servise(DEGMAX), 70, 255) : 150) : _kul) : ((amp >= _curfan[curfanOn]) ? (_kul ? map_my(amp, _curfan[curfanOff], _curfan[curfanMax], 70, 255) : 150) : _kul);
        // если кулер включен
        if (_kul) {
          _kul = temp_Q1 ? ((temp_Q1 <= get_epprom_servise(DEGOFF)) ? 0 : _kul) : ((amp <= _curfan[curfanOff]) ? 0 : _kul);
        }
        analogWrite_my(PWMKUL, _kul);
        break;

      case 2:
        // управление кулером вкл/откл
        // если кулер включен
        if (_kul) {
          _kul = temp_Q1 ? (temp_Q1 <= get_epprom_servise(DEGOFF) ? false : _kul) : ((amp <= _curfan[curfanOff]) ? false : _kul);
        } else {
          // если кулер отключен
          _kul = temp_Q1 ? (temp_Q1 >= get_epprom_servise(DEGON) ? true : _kul) : ((amp >= _curfan[curfanOn]) ? true : _kul);
        }
        gio::write(PWMKUL, _kul);
        break;
    }
  }

private:
  uint8_t _kul;  // значение ШИМ кулера
  int16_t _curfan[3];
  enum : uint8_t {
    curfanOn,
    curfanOff,
    curfanMax
  };
};
extern KULER kul;
KULER kul = KULER();
#endif
//int16_t _curfanOn;   // значение тока в Амперах при котором включается вентилятор. (до 25,5А) define в 2_menu.h
//int16_t _curfanOff;  // значение тока в Амперах при котором отключается вентилятор. (до 25,5А)
//int16_t _curfanMax;  // значение тока в Амперах  для максимальных оборотов вентилятора ШИМ. (до 25,5А)

// настройка команд энкодера и кнопок
#define LEFT -1
#define RIGHT 1
#define OKCLICK 16
#define OKHELD 12
#define STOPCLICK 36
#define STOPHELD 22
#define PLUSHELD 32
#define MINUSHELD 42
class Enbutt {
public:
  // Enbutt(void){};

  int8_t tick;
  // функция опрашивает энкодер и кнопки.
  inline void Tick(void) {
    tick = 0;
// -1 - left, 1 - right, 16 - click, 2 - hold, 4 - step
#if (ENCBUTT == 0)
    // 0 - только энкодер
    if (enc.tick()) {
      if (enc.turn()) tick = enc.dir();  // -1 - left, 1 - right,
      else {
        if (enc.click()) tick = OKCLICK;
        if (enc.hold()) tick = OKHELD;
      }
    }
#elif (ENCBUTT == 1)
    // 1 - только кнопки
    if (OK.tick()) {
      if (OK.click()) tick = OKCLICK;
      if (OK.hold()) tick = OKHELD;
    }
    if (Stop.tick()) {
      if (Stop.click()) tick = STOPCLICK;
      if (Stop.hold()) tick = STOPHELD;
    }
    if (Plus.tick()) {
      if (Plus.click() or Plus.step()) tick = RIGHT;
    }
    if (Minus.tick()) {
      if (Minus.click() or Minus.step()) tick = LEFT;
    }
#elif (ENCBUTT == 2)
    // 2 - энкодер + OK + Stop
    if (enc.tick()) {
      if (enc.turn()) tick = enc.dir();  // -1 - left, 1 - right,
      else {
        if (enc.click()) tick = OKCLICK;
        if (enc.hold()) tick = OKHELD;
      }
    }
    if (OK.tick()) {
      if (OK.click()) tick = OKCLICK;
      if (OK.hold()) tick = OKHELD;
    }
    if (Stop.tick()) {
      if (Stop.click()) tick = STOPCLICK;
      if (Stop.hold()) tick = STOPHELD;
    }
#elif (ENCBUTT == 3)
    // 3 - энкодер + все кнопки
    if (enc.tick()) {
      if (enc.turn()) tick = enc.dir();  // -1 - left, 1 - right,
      else {
        if (enc.click()) tick = OKCLICK;
        if (enc.hold()) tick = OKHELD;
      }
    }
    if (OK.tick()) {
      if (OK.click()) tick = OKCLICK;
      if (OK.hold()) tick = OKHELD;
    }
    if (Stop.tick()) {
      if (Stop.click()) tick = STOPCLICK;
      if (Stop.hold()) tick = STOPHELD;
    }
    if (Plus.tick()) {
      if (Plus.click() or Plus.step()) tick = RIGHT;
    }
    if (Minus.tick()) {
      if (Minus.click() or Minus.step()) tick = LEFT;
    }
#endif
#if (TIME_LIGHT)
    if (tick) disp.Light_high();
#endif
  }
  //private:
};
extern Enbutt butt;
Enbutt butt = Enbutt();


// отправка значений в сетевой порт
#if (LOGGER)

class Serial_Out {
public:
  // Serial_Out(){}

  // формируем основные данные
  void create(int32_t Achas = 0, uint16_t volt = 0, int16_t amper = 0) {
    send_str.volt = volt ? volt : ina.voltsec;      //напряжение на АКБ (милливольт)/1000
    send_str.amper = amper ? amper : ina.ampersec;  //ток АКБ (миллиампер)/1000
#if defined(__LGT8FX8P__)
    send_str.Achas = Achas ? DSC_DIV_get((int32_t)(Achas + 500), (uint16_t)1000) : 0;  //Полученная_отданная емкость АКБ (А/ч)) /1000
#else
    send_str.Achas = Achas ? (Achas + 500) / 1000 : 0;  //Полученная_отданная емкость АКБ (А/ч)) /1000
#endif


#if (VOLTIN == 1)
    send_str.volt_in = adc_v.volt;  //напряжение от БП (милливольт) /1000
#endif
#if (SENSTEMP1 > 0)
    send_str.tQ1 = temp_Q1;  //Температура на Q1 (градусы)
#endif
#if (SENSTEMP2 > 0)
    send_str.tAkb = temp_akb;  //6 Температура АКБ (градусы)
#endif
  }

// Расширенные данные LOGGER = 4
  void create_advanced(int32_t Achas = 0, uint16_t volt = 0, int16_t amper = 0, uint32_t time_current = 0) {
    send_str_adv.volt = volt ? volt : ina.voltsec;
    send_str_adv.amper = amper ? amper : ina.ampersec;
#if defined(__LGT8FX8P__)
    send_str_adv.Achas = Achas ? DSC_DIV_get((int32_t)(Achas + 500), (uint16_t)1000) : 0;
#else
    send_str_adv.Achas = Achas ? (Achas + 500) / 1000 : 0;
#endif

#if (VOLTIN == 1)
    send_str_adv.volt_in = adc_v.volt;
#endif
#if (SENSTEMP1 > 0)
    send_str_adv.tQ1 = temp_Q1;
#endif
#if (SENSTEMP2 > 0)
    send_str_adv.tAkb = temp_akb;
#endif

    // Дополнительные данные
    send_str_adv.mode = pam.Mode;
    send_str_adv.type_akb = pam.typeAkb;
    send_str_adv.capacity = pam.Capacity;
    send_str_adv.active_flag = bitRead(pam.MyFlag, ACTIVITI);
    send_str_adv.round_current = pam.Round;
    send_str_adv.profil = vkr.profil;
    send_str_adv.time_charge = time_current;

    send_str_adv.Wh_charge = pam.Wh_charge / 1000;
    send_str_adv.regim_end = regim_end;
  }

  // Вывод логов в сетевой порт. Вызывать постоянно раз в секунду
  inline void Serial_out(void) {
    if (--_tm == 0) {
      _tm = LOGGTIME;

#if (LOGGER == 1)
      send_str.crc = 0;
      for (uint8_t i = 0; i < sizeof(Log_get) - 1; i++) {
        send_str.crc += ptr[i];  // Расчет контрольной суммы
        mSerial.write(ptr[i]);   // передать данные
      }
      mSerial.write(ptr[sizeof(Log_get) - 1]);  // передать символ CRC

#elif (LOGGER == 2)
      _time += LOGGTIME;
      mSerial.print(F(txt_ViktoRi));  // ViktoRi  // начало посылки
      mSerial.write(';');
      mSerial.print(_time);  // время
      mSerial.write(';');
      serial_print(fl((float)send_str.volt), 3);
      serial_print(fl((float)send_str.amper), 3);
      serial_print(fl((float)send_str.Achas), 4);
#if (VOLTIN == 1)
      serial_print(fl((float)send_str.volt_in), 3);  //напряжение от БП Вольт
#endif
#if (SENSTEMP1)
      serial_print((float)send_str.tQ1, 0);  //Температура на Q1 (градусы)
#endif
#if (SENSTEMP2)
      serial_print((float)send_str.tAkb, 0);  //6 Температура АКБ (градусы)
#endif
      mSerial.println();  // конец посылки

#elif (LOGGER == 3)
      mSerial.write('$');  // начало посылки
      serial_print(send_str.volt);
      serial_print(send_str.amper);
      serial_print(send_str.Achas);
#if (VOLTIN == 1)
      serial_print(send_str.volt_in);  //напряжение от БП (милливольт)/1000
#endif
#if (SENSTEMP1)
      serial_print(send_str.tQ1);  //Температура на Q1 (градусы)
#endif
#if (SENSTEMP2)
      serial_print(send_str.tAkb);  //6 Температура АКБ (градусы)
#endif
      mSerial.write(';');  // конец посылки
      
#elif (LOGGER == 4)
      // Расширенный лог
      send_str_adv.crc = 0;
      for (uint8_t i = 0; i < sizeof(Log_get_advanced) - 1; i++) {
        send_str_adv.crc += ptr_adv[i];  // Расчет контрольной суммы
        mSerial.write(ptr_adv[i]);       // передать данные
      }
      mSerial.write(ptr_adv[sizeof(Log_get_advanced) - 1]);  // передать символ CRC
#endif
    }
  }

private:
  uint8_t _tm = LOGGTIME;

#pragma pack(push, 1)
  struct Log_get {
    uint8_t start_send;  //маркер старта
    uint8_t len_send;    //длина посылки
    uint8_t cod_send;    //код данных

    uint16_t volt;  // 1 напряжение на АКБ (милливольт)
    int16_t amper;  // 2 ток АКБ (миллиампер)
    int32_t Achas;  // 5 Полученная_отданная емкость АКБ в Ач

    uint16_t volt_in;  // 4 напряжение от БП (милливольт)
    int8_t tQ1;        // 3 Температура на Q1 (градусы)
    int8_t tAkb;       // 6 Температура АКБ (градусы)
    uint8_t crc;       //контролная сумма
  };
#pragma pack(pop)
  Log_get send_str{ ':', sizeof(Log_get) - 1, '1', 0, 0, 0, 0, 0, 0, 0 };
  uint8_t *ptr = ((uint8_t *)&send_str);

// Расширенный лог (LOGGER == 4) 30 байт
#pragma pack(push, 1)
  struct Log_get_advanced {
    uint8_t start_send;     // маркер старта ":" (0x3A)
    uint8_t cod_send;       // код данных '4'

    uint16_t volt;          // напряжение АКБ (мВ)
    int16_t amper;          // ток АКБ (мА)
    int32_t Achas;          // емкость заряда А/ч
    uint16_t volt_in;       // напряжение БП (мВ)
    int8_t tQ1;            // температура транзистора
    int8_t tAkb;           // температура АКБ

    // Дополнительные параметры
    uint8_t mode;           // индекс режима работы (0-8)
    uint8_t type_akb;       // индекс типа АКБ (0-8)
    uint8_t capacity;       // емкость АКБ (Ач)
    uint8_t active_flag;    // устройство в работе (0/1)
    uint8_t round_current;  // текущий круг/цикл
    uint8_t profil;         // номер активного профиля (0-9)

    uint32_t time_charge;   // время с начала зарядки (сек)
    int32_t Wh_charge;      // энергия заряда (Вт/ч)
    uint8_t regim_end;      // причина завершения (0-5)

    uint8_t crc;           // контрольная сумма
  };
#pragma pack(pop)

  Log_get_advanced send_str_adv{ ':', '4', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
  uint8_t *ptr_adv = ((uint8_t *)&send_str_adv);

#if (LOGGER == 2)
  void serial_print(float x, uint8_t y) {
    mSerial.print(x, y);
    mSerial.write(';');
  }

  float fl(float y) {
    return y / 1000;
  }
  uint32_t _time = 0;
#endif

#if (LOGGER == 3)
  void serial_print(int32_t x) {
    mSerial.print(x);
    mSerial.write(' ');
  }
#endif
};
extern Serial_Out Sout;
Serial_Out Sout = Serial_Out();
#endif

// библиотека для работы с ЦАП MCP4725
// просто отправляет значение 0-4095 напряжения в MCP4725
#if (MCP4725DAC)
//#include <microWire.h>
class MCP4725 {
public:
  // инициализация
  MCP4725(uint8_t addr)
    : _address(addr) {}

  // Запись 16-ти битного регистра MCP4725
  void setVoltage(uint16_t data) {
    Wire.beginTransmission(_address);         // Начинаем передачу
    Wire.write(0b01000000);                   // передаем контрольный байт (010-Sets in Write mode)
    Wire.write((uint8_t)(data >> 4));         // Upper data bits (D11.D10.D9.D8.D7.D6.D5.D4)Отправляем старший байт
    Wire.write((uint8_t)((data % 12) << 4));  // Lower data bits (D3.D2.D1.D0.x.x.x.x));         // Отправляем младший байт
    Wire.endTransmission();                   // Заканчиваем передачу
  }

  // Проверка присутствия
  bool testConnection(void) {
    Wire.beginTransmission(_address);      // Начинаем передачу
    return (bool)!Wire.endTransmission();  // Сразу заканчиваем
  }

private:
  const uint8_t _address;
};
extern MCP4725 dac;
MCP4725 dac = MCP4725(ADDR4725);

#endif
