#include <Arduino.h>
#include "1_User_Setup.h"

#define DCDC_CHARGE true      // заряд
#define DCDC_DISCHARGE false  // разряд
// класс управления DC-DC модулем
class DCDC {
public:
  // DCDC(void){};

  void start(bool mods) {
    _cur_max = CURRMAXINT;
    _err_pred = 0;
    _Integral = 0.0;
    _cur_charge = 0;
    _tok = 0;
    _tok_pred = _tok;
    _flags = 0b00000011;           // флаги // 0 пауза, 1 плавный пуск, 2 режим (заряд/ разряд)
    bitWrite(_flags, Mode, mods);  // установить режим работы заряд/разряд
    _time_sec = 300;
  }

  // отключить плавный пуск - вызывать после start() и перед begin()
  void Smooth_off(bool x) {
    bitWrite(_flags, Smooth, x);
  }

  // задать максимальные значения напряжения и тока заряда
  void begin(uint16_t volt_charge, int16_t cur_charge) {
    _volt_charge = volt_charge;
    _cur_charge_max = cur_charge;
    if (cur_charge <= 800) _cur_charge = _cur_charge_max;
    else _cur_charge = bitRead(_flags, Smooth) ? _cur_charge_max >> 3 : _cur_charge_max;  // если отключен плавный пуск
  }

  // величина ошибки
  int16_t Err(void) {
    int16_t volt_err = bitRead(_flags, Mode) ? difference(_volt_charge, ina.voltms) : difference(ina.voltms, _volt_charge);  // величина ошибки по напряжению
    int16_t amp_err = _cur_charge - abs(ina.amperms);                                                                        // величина ошибки по току
    return (volt_err < amp_err) ? volt_err : amp_err;                                                                        // регулируем напряжение или ток
  }

  // регулировка напряжения и тока заряда
  void Control(void) {
    if (bitRead(pam.MyFlag, ACTIVITI) and bitRead(_flags, Pause)
#if (VOLTIN)
        and bitRead(flag_global, POWERHIGH)
#endif
#if (CORRECTCUR and SENSTEMP2)
        and bitRead(flag_global, TEMP_AKB)
#endif
    ) {
#if (VOLTIN)
      if (bitRead(_flags, Mode) and BitIsClear(flag_global, POWERON)) return;  // если включен заряд а напряжения от БП нет
#endif
      if (abs(ina.amperms) > _cur_max and _tok > 0) _tok--;
      else {

        if (--_time_sec == 0) {
          _time_sec = 300;
          // плавный пуск - плавное увеличение тока заряда/разряда
          if (bitRead(_flags, Smooth)) {
            _cur_charge += (_cur_charge_max >> 3);
            _cur_charge = constrain(_cur_charge, 0, _cur_charge_max);
            if (_cur_charge == _cur_charge_max) bitClear(_flags, Smooth);  // отключить плавный пуск
          }
#if (SENSTEMP1 and GUARDTEMP)
          else {
            // если превышена температура то уменьшаем ток иначе увеличиваем
            _cur_charge += (bitRead(flag_global, TR_Q1_ERR) ? -10 : 10);
            _cur_charge = constrain(_cur_charge, _cur_charge_max >> 1, _cur_charge_max);
          }
#endif
        }

        int16_t err = Err();  // величина ошибки
        if (err == 0) return;

        float P = 0.001f * err;
        _Integral += P;
        P += _Integral;
        P += (float)(_err_pred - err) * 0.0005;
        _err_pred = err;

#if (MCP4725DAC)
        _tok = bitRead(_flags, Mode) ? constrain((uint16_t)(P + 0.5), 0, 4095) : constrain((uint16_t)(_Integral + 0.5), 0, 255);  // регулировка тока
#else
        int16_t t = (int16_t)(P + 0.5);  // регулировка тока
        _tok = (uint8_t)constrain(t, 0, 255);
#endif
      }
#if (MCP4725DAC)
      bitRead(_flags, Mode) ? dac.setVoltage(_tok) : analogWrite_my(PWMDCH, _tok);
#else
      analogWrite_my((bitRead(_flags, Mode) ? PWMCH : PWMDCH), _tok);
#endif
    }
  }

  void pause(bool x) {
    bitWrite(_flags, Pause, x);
#if (MCP4725DAC)
    bitRead(_flags, Mode) ? dac.setVoltage(x ? _tok : 0) : digitalWrite_speed(PWMDCH, LOW);  // отключаем заряд/разряд
#else
    analogWrite_my((bitRead(_flags, Mode) ? PWMCH : PWMDCH), (x ? _tok : 0));  // отключить/включить заряд/разряд
#endif
  }

  void Off(void) {
    pause(LOW);
    Smooth_off(HIGH);  // включить плавный пуск
    _Integral = 0.0;
  }

  void setVolt_charge(uint16_t v) {
    _volt_charge = v;
  }

  void setCur_charge(int16_t v) {
    _cur_charge_max = v;
    _cur_charge = v;
  }

  uint16_t getVolt_charge(void) {
    return _volt_charge;
  }

  int16_t getCur_charge(void) {
    return _cur_charge_max;
  }


#if (MCP4725DAC)
  void setTok(uint16_t v) {
    _tok = v;
  }

  uint16_t getTok(void) {
    return _tok;
  }
#else
  void setTok(uint8_t v) {
    _tok = v;
  }

  uint8_t getTok(void) {
    return _tok;
  }
#endif

  bool get_pause(void) {
    return bitRead(_flags, Pause);
  }

private:
  // список членов для использования внутри класса
  uint16_t _volt_charge;    // напряжение заряда
  int16_t _cur_max;         // предельный ток зарядника
  int16_t _cur_charge_max;  // максимальный ток заряда
  int16_t _cur_charge;      // текущий ток заряда
#if (MCP4725DAC)
  uint16_t _tok = 0;  // значение ШИМ
#else
  uint8_t _tok = 0;       // значение ШИМ
  uint8_t _tok_pred = 0;  // значение ШИМ предыдущ
#endif
  int16_t _err_pred;
  float _Integral;
  uint16_t _time_sec;

  uint8_t _flags = 0b00000000;  // флаги
  enum : uint8_t {
    Pause,   // пауза
    Smooth,  // плавный пуск
    Mode,    // режим (заряд/ разряд)
  };
};

extern DCDC dcdc;
DCDC dcdc = DCDC();
