// собираем веб морду
void build(sets::Builder& b) {
  // название вкладок для switch
  enum Tabs : uint8_t {
    Hello,
    Grafik,
    Sett_loger
  } static tab;

  // Названия вкладок для интерфейса
  if (b.Tabs("Привет;График;Настройки", (uint8_t*)&tab)) {
    b.reload();  // при нажатии перезагружаемся и выходим
    return;
  }

  switch (tab) {
    case Tabs::Hello:
      // текущие значения, график
      {
        sets::Group g(b, "Текущие значения");
        sett.attachDB(&db_ram);        
        b.LabelFloat(logs::volt, "Напряжение", (float)send.volt / 1000, 3);
        b.LabelFloat(logs::amper, "Ток", (float)send.amper / 1000, 3);
        b.LabelFloat(logs::Achas, "Ампер*часы", (float)send.Achas / 1000, 3);
      }
      //b.PlotStack(H(stack), "Вольт;Ампер");      
      b.PlotRunning(H(run), "Вольт[В];Аmper[А];Ач[Aч];БП[В];Темп Q1[Гр];Темп АКБ[Гр]", 1000);  // обновление графика 1000 мсек
      break;
    case Tabs::Grafik:
      // селект с графиком из файла ".csv" или ".tbl"
      {
        sets::Group g(b, "Выбор файла графика");
        sett.attachDB(&db_ram);
        if (db_ram.get(logs::SD_ok)) {
          String s;
          sett.fs.sd.listDir(s);  // вывести список файлов sd (без префикса /sd/)
          b.Select(logs::sd_file, "Файлы на карте памяти", s);
          s = Text(s).getSub(db_ram[logs::sd_file], '\n').toString();  // вырезать название файла по номеру вхождения
          if (s.endsWith(".csv") or s.endsWith(".tbl")) {
            // если файл .csv вывести график
            s = "/sd" + s;
            Serial.println(s);
            b.Plot(H(Plot), s, "Вольт[В];Аmper[А];Ач[Aч];БП[В];Темп Q1[Гр];Темп АКБ[Гр]");  // из csv таблицы
          }
          b.reload();
        } else {
          b.Label("Ошибка SD карты");
        }
      }
      break;
    case Tabs::Sett_loger:
      // ввести название вашей сети Wi-Fi и пароль
      {
        sets::Group g(b, "Ваша сеть Wi-Fi");
        sett.attachDB(&db);
        b.Input(keyDB::wifi_ssid, "Имя сети");
        b.Pass(keyDB::wifi_pass, "Пароль");
        if (b.Button(keyDB::wifi_apply, "Сохранить и перезагрузить")) {
          db.update();    // сохраняем БД не дожидаясь таймаута
          ESP.restart();  // перезагрузить ESP
        }
      }
      break;
  }
}

// обновление виджетов
void update(sets::Updater& u) {
  u.update(logs::volt, (float)send.volt / 1000, 3);
  u.update(logs::amper, (float)send.amper / 1000, 3);
  u.update(logs::Achas, (float)send.Achas / 1000, 3);

  float v[] = { (float)send.volt / 1000, (float)send.amper / 1000, (float)send.Achas / 1000, (float)send.volt_in / 1000, (float)send.tQ1, (float)send.tAkb };  // напряжение и ток
  // u.updatePlot(H(stack), v);
  u.updatePlot(H(run), v);  // график на первой странице
}