#include <Arduino.h>
#include <SPI.h>
// БИБЛИОТЕКА SD КАРТЫ
#ifdef ESP8266
#include <SDFS.h>
#else  // ESP32
#include <SD.h>
#endif
//#include <LittleFS.h>
#include <SettingsGyver.h>
#include <GyverDBFile.h>
#include <GyverDB.h>
#include <TableFileStatic.h>
#include <GyverNTP.h>
#include "my_functions.h"

#define POYAS 3  // - часовой пояс

// если нужно впиши данные  сети WI-Fi своего роутера.
// подключаться будет всегда только к этой сети
#define HomeSSID ""       // название домашней WiFi сети
#define HomePass ""       // пароль домашней WiFi сети
#define HomeIP "192.168.0.130"    // желаемый IP адрес
#define HomeGate "192.168.0.1"    // адрес роутера
#define HomeMask "255.255.255.0"  // маска, оставь как есть
#define HomeDNS HomeGate          // "192.168.0.1"

// пины для SD карты
#if defined(CONFIG_IDF_TARGET_ESP32S3)
const int sck = 14;   // SCK = 12
const int miso = 7;   // MISO = 13
const int mosi = 23;  // MOSI = 11
const int cs = 21;    // SS = 10
#elif defined(ESP32)
const int sck = SCK;
const int miso = MISO;
const int mosi = MOSI;
const int cs = SS;
#elif defined(ARDUINO_ARCH_ESP8266)
const int sck = 14;   // D5 - 14
const int miso = 12;  // D6 - 12
const int mosi = 13;  // D7 - 13
const int cs = 15;    // D8 - 15
#endif

GyverDB db_ram;                         // создать БД в оперативке
GyverDBFile db(&LittleFS, "/data.db");  // создать БД в постоянной памяти

SettingsGyver sett("ViktoRi", &db);  // подключить БД

// имена ячеек БД в оперативке
DB_KEYS(
  logs,  // название ключей
  volt,
  amper,
  Achas,
  sd_file,
  sd_file_name,
  SD_ok,
  wifi_ok);

// имена ячеек БД в постоянной памяти
DB_KEYS(
  keyDB,  // название ключей
  wifi_ssid,
  wifi_pass,
  wifi_apply,
  tyme_real);

// веб интерфейс
void build(sets::Builder& b);

// обновление виджетов
void update(sets::Updater& u);

void setup() {
  // серийный порт
  Serial.begin(9600);     // скорость, бод
  Serial.setTimeout(10);  // таймоут, мс
  Serial.println();

  // запуск и инициализация полей БД
  db_ram[logs::volt] = 0.0;
  db_ram[logs::amper] = 0.0;
  db_ram[logs::Achas] = 0.0;
  db_ram[logs::sd_file] = 0;
  db_ram[logs::sd_file_name] = "";
  db_ram[logs::SD_ok] = false;
  db_ram[logs::wifi_ok] = false;

  // инициализация LittleFS
  if (!LittleFS.begin()) {
    Serial.println("LittleFS mount failed - 1");
    Serial.println("Formatting LittleFS filesystem");
    LittleFS.format();  // отформатировать память esp
    LittleFS.end();
    if (!LittleFS.begin()) {
      Serial.println("LittleFS mount failed - 2. END");
      return;
    }
  }
  Serial.println("LittleFS mount OK");

  // запуск и инициализация полей БД
  db.begin();
  // данные Wi-Fi сети записывается в БД при инициализации
  db.init(keyDB::wifi_ssid, HomeSSID);
  db.init(keyDB::wifi_pass, HomePass);
  db.init(keyDB::wifi_apply, false);      // хз
  db.init(keyDB::tyme_real, 1744448166);  // инициализация поля времени далее, после запроса времени из интернета

  // Настройка SD карты
  Serial.print("Подключение SD карты...");
#ifdef ESP8266
  SPI.begin();
  // карта подключена к SPI(MOSI/MISO/CLK) + CS на пине D8 (по умолчанию там D4)
  SDFSConfig cfg(cs);
  SDFS.setConfig(cfg);

  if (SDFS.begin()) {
    db_ram.set(logs::SD_ok, true);
    sett.fs.setFS(LittleFS, SDFS);  // подключение обеих FS
    Serial.println("OK");
  } else {
    db_ram.set(logs::SD_ok, false);
    Serial.println("ОШИБКА");
  }
#else  // ESP32

  SPI.begin(sck, miso, mosi, cs);  // назначить пины для SD карты
  if (SD.begin(cs)) {
    db_ram.set(logs::SD_ok, true);
    sett.fs.setFS(LittleFS, SD);  // подключение обеих FS
    Serial.println("OK");
  } else {
    db_ram.set(logs::SD_ok, false);
    Serial.println("ОШИБКА");
  }
#endif


  // если данные Wi-Fi сети заданы - подключаемся
  if (db[keyDB::wifi_ssid].length()) {
    //
    WiFi.mode(WIFI_STA);    // режим клиента
    IPAddress ip;           // создаем объект IP адреса
    ip.fromString(HomeIP);  // присваиваем ему статический IP адрес при подключении к домашнему роутеру
    IPAddress gateway;      // Указываем статический шлюз при подключении к домашнему роутеру
    gateway.fromString(HomeGate);
    IPAddress subnet;  // Указываем статическую маску сети при подключении к домашнему роутеру
    subnet.fromString(HomeMask);
    IPAddress dns;  // Указываем DNS
    dns.fromString(HomeDNS);
    WiFi.config(ip, dns, gateway, subnet);                   // Указываем что DHCP домашнего роутера будет игнорироваться. У датчика будет статический IP, GateWay и Маска
    WiFi.begin(db[keyDB::wifi_ssid], db[keyDB::wifi_pass]);  // WiFi.begin(HomeSSID, HomePass);

    Serial.print("Подключение к сети Wi-fi(STA) ");
    Serial.print(db[keyDB::wifi_ssid]);  // имя вашей сети
    int tries = 20;
    while (WiFi.status() != WL_CONNECTED) {
      delay(500);
      Serial.print('.');
      if (!--tries) break;
    }
    if (WiFi.status() == WL_CONNECTED) {
      Serial.println(" успешно");
      Serial.print("IP: ");
      Serial.println(WiFi.localIP());
      db_ram.set(logs::wifi_ok, true);
    } else {
      Serial.println(" не успешно");
      Serial.print("Запускаю точку доступа ViktoRi");
      // ... иначе запускаем точку доступа - "Viktori"
      // ======= AP =======
      WiFi.mode(WIFI_AP_STA);
      WiFi.softAP("ViktoRi");
      Serial.print("AP IP: ");
      Serial.println(WiFi.softAPIP());
    }
  } else {
    // ... иначе запускаем точку доступа - "Viktori"
    Serial.println("Запускаю точку доступа ViktoRi");
    // ======= AP =======
    WiFi.mode(WIFI_AP_STA);
    WiFi.softAP("ViktoRi");
    Serial.print("AP IP: ");
    Serial.println(WiFi.softAPIP());
  }

  // settings
  sett.begin();
  sett.onBuild(build);
  sett.onUpdate(update);
  // использовать автоматические обновления из БД (при изменении записи новое значение отправится в браузер)
  sett.useAutoUpdates(true);
  //setStampZone(3); // часовой пояс для rtc

  // установить хост (умолч. "pool.ntp.org")
  // NTP.setHost("ntp0.ntp-servers.net");
  bool time_online_ok = false;
  time_online_ok = NTP.begin(3);  // запустить и указать часовой пояс

  Serial.print("Time synchronization ");
  uint8_t op = 10;
  while (op--) {
    Serial.print(".");
    time_online_ok = NTP.updateNow();  // синхронизировать
    if (time_online_ok) {
      db.set(keyDB::tyme_real, NTP.getUnix());  // сохранить в базе данных текущее время
      Serial.print("Time synchronization OK: ");
      Serial.println(db.get(keyDB::tyme_real));
      // вывод даты и времени строкой
      Serial.println(NTP.toString());
      break;
    }
  }

  //NTP.setPeriod(3600); // синхронизация каждые 3600 секунд // 1 час по умолчанию
  sett.rtc.sync(db.get(keyDB::tyme_real));  // установить из unix времени и глобального часового пояса setStampZone
  Serial.print("Текущее время: ");
  Serial.println(db.get(keyDB::tyme_real));
  Serial.print("Время NTP: ");
  Serial.println(NTP.getUnix());

  db.dump(Serial);
  Serial.println();
  db_ram.dump(Serial);
  delay(1000);
}

void loop() {
  bool logi_ok = false;
  // создать новое имя файла по дате и времени
  String name_file;
  name_file += "/";
  name_file += String(sett.rtc.year());  // год
  name_file += "-";
  name_file += String(sett.rtc.month());  // месяц
  name_file += "-";
  name_file += String(sett.rtc.day());  // день
  name_file += "_";
  name_file += String(sett.rtc.hour());  // час
  name_file += "-";
  name_file += String(sett.rtc.minute());  // минута
  name_file += ".tbl";

  Serial.println(name_file);

#ifdef ESP32
  TableFileStatic logi_tab(&SD, name_file.c_str());
#elif ESP8266
  TableFileStatic logi_tab(&SDFS, name_file.c_str());
#endif
  // инициализация таблицы на SD карте - кол-ва столбцов и типов, если файл ещё не существует
  logi_ok = logi_tab.init(7, cell_t::Uint32, cell_t::Float, cell_t::Float, cell_t::Float, cell_t::Float, cell_t::Int8, cell_t::Int8);

  if (logi_ok) {
    Serial.println("Инициализации таблицы на карте SD успешна");
    // добавить данные напрямую в файл
    logi_ok = logi_tab.append(sett.rtc.getUnix(), 0.0, 0.0, 0.0, 0.0, 0, 0);
    if (logi_ok) Serial.println("Запись на карту SD успешна");
    else Serial.println("Ошибка записи на карту SD");
  } else Serial.println("Ошибка инициализации таблицы на карте SD");

  auto time_save = millis();

  while (true) {
    sett.tick();
    //NTP.tick();

    // прием данных от ЗУ
    if (Serial_get()) {
      float volt_fl = (float)send.volt / 1000;
      float amper_fl = (float)send.amper / 1000;
      float Ah_fl = (float)send.Achas / 1000;
      float bp_volt_fl = (float)send.volt_in / 1000;

      if (db_ram.get(logs::SD_ok) and logi_ok) {
        // добавить данные напрямую в файл
        logi_tab.append(sett.rtc.getUnix(), volt_fl, amper_fl, Ah_fl, bp_volt_fl, send.tQ1, send.tAkb);
      }
    }

    if (millis() - time_save >= 3600000) {
      time_save = millis();
      if (NTP.updateNow()) {                      // синхронизировать
        db.set(keyDB::tyme_real, NTP.getUnix());  // сохранить в базе данных текущее время
        sett.rtc.sync(db.get(keyDB::tyme_real));  // установить из unix времени и глобального часового пояса setStampZone
        Serial.println("Время синхронизированно.");
      } else db.set(keyDB::tyme_real, sett.rtc.getUnix());
    }
  }
}
