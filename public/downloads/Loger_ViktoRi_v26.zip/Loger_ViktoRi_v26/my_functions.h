#include <Arduino.h>
#include <HardwareSerial.h>

// структура данных принимаемых от ЗУ
#pragma pack(push, 1)
struct Log_get {
  uint8_t start;  // маркер старта
  uint8_t len;    // длина посылки
  uint8_t cod;    // код данных

  uint16_t volt;  // 1 напряжение на АКБ (милливольт)
  int16_t amper;  // 2 ток АКБ (миллиампер)
  int32_t Achas;  // 3 Полученная_отданная емкость АКБ в Ач

  uint16_t volt_in;  // 4 напряжение от БП (милливольт)
  int8_t tQ1;        // 5 Температура на Q1 (градусы)
  int8_t tAkb;       // 6 Температура АКБ (градусы)
  uint8_t crc;       //контролная сумма
};
#pragma pack(pop)

Log_get send{ ':', sizeof(Log_get) - 1, '1', 0, 0, 0, 0, 0, 0, 0 };  // 16 байт

// прием данных от ЗУ
bool Serial_get(void) {
  while (Serial.available()) {
    if (Serial.peek() == ':') {
      Log_get send_get;
      uint8_t *ptr1 = ((uint8_t *)&send_get);
      Serial.readBytes(ptr1, sizeof(Log_get));
      uint8_t crc = 0;
      for (uint8_t i = 0; i < sizeof(Log_get) - 1; i++) crc += ptr1[i];  // Расчет контрольной суммы 
      if (send_get.crc == crc) {
        //send = send_get;
        send.volt = send_get.volt;
        send.amper = send_get.amper;
        send.Achas = send_get.Achas;
        send.volt_in = send_get.volt_in;
        send.tQ1 = send_get.tQ1;
        send.tAkb = send_get.tAkb;
        return true;
      }      
      return false;
    } else Serial.read();
  }
  return false;
}


/*
// Функция для поиска и возврата имени файла по его номеру.
// принимает 2 значения:
// - строку вида "/file1.txt\n/file2.txt\n/file3.txt\n/file4.txt\n/file5.txt\n/file6.txt\n" в которой перечислены имена файлов;
// - номер файла.
String getFileName(String fileList, int fileNumber) {
  int currentFileNumber = 0;
  int pos = 0;
  String fl;
  fl = "";
  while (pos < fileList.length()) {
    // Поиск следующего символа '/'
    pos = fileList.indexOf('/', pos);

    if (currentFileNumber == fileNumber) {
      int start = pos;
      pos++;
      pos = fileList.indexOf("\n", pos);
      fl = fileList.substring(start, pos);
      return fl;
    } else {
      pos++;
      currentFileNumber++;
    }
  }
  return fl;
}
*/

/*
// вывести всё содержимое БД
    void dump(Print& p) {
        p.print(F("DB dump: "));
        p.print(length());
        p.print(F(" entries ("));
        p.print(size());
        p.println(F(" bytes)"));
        for (size_t i = 0; i < length(); i++) {
            if (i <= 9) p.print(0);
            p.print(i);
            p.print(F(". 0x"));
            p.print(_buf[i].keyHash(), HEX);
            p.print(F(" ["));
            p.print(_buf[i].typeRead());
            p.print(F("]: "));
            p.println(gdb::Entry(_buf[i]));
        }
    }
*/